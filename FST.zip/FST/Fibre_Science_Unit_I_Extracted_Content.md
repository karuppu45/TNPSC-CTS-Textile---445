# Extracted Content — Unit I: Fibre Properties and Man-Made Fibre Spinning
### Source: *A Text Book of Fibre Science and Technology*, S.P. Mishra (New Age International Publishers, 2000)

> **Note on source quality:** This book is a photographed/scanned copy (not a clean flat-bed scan), so several pages are skewed, shadowed, or low-contrast. OCR text extraction was used to locate and transcribe the relevant passages. The technical content, terminology, data and tables below are reproduced as faithfully as the scan quality allows; a small number of individual words that were illegible in the scan have been reconstructed from context (chemistry/technical continuity) and are indicated in [brackets] where the reconstruction is non-trivial. Diagrams and micrographs referenced in the text (figure numbers are cited) could not be perfectly reproduced as images here — they are described narratively where they appear. For pixel-perfect figures/tables, please refer to the original PDF page numbers cited under each topic.

---

## Topic i) Definition of Textile Fibre; Properties Required for an Ideal Textile Fibre

* **Chapter:** 1 – Introduction (to Textile Fibres)
* **Page Number(s):** Book pp. 1–10 (PDF pages 14–23)
* **Extracted Content:**

The chapter opens with the historical background of fibre use: *"The use of fibres for textile purposes is one of mankind's oldest arts. So the study of textile fibres has become a very interesting and challenging science. This study is related to their sources, processing, properties and utilisation."* The history of fibre development is described as "a strange pattern of trial and error ever since fibre began to be used for making apparel," with the means of twisting fibres to cords, plaiting and sewing dating from the palaeolithic age. Until about 100 years ago, all fibres used by man were natural — vegetable fibres (cotton, flax/linen, jute), developed earliest and most widely used because vegetable fibre development was influenced by climate; wool, hair and fur fibres developed in cold countries; and silk, the "most marvellous and expensive fibre," used by noble and privileged classes, with the earliest preserved Chinese references to silk dating to 530 B.C.

The book then traces the development of man-made fibres: nitrocellulose fibres (Schutzenberger and Naudin; commercialised by Chardonnet, 1885 — "Chardonnet silk"), cuprammonium rayon (Despeissis, 1890, using ammoniacal copper solution), the viscose (xanthation) process discovered by Cross and Bevan in England (British Patent 8,700, 1892), cellulose triacetate (Cross and Bevan, 1894), and secondary cellulose acetate (1903). It records that **the truly synthetic fibre era began in the U.S.A. and Germany between 1928 and 1939**: W.H. Carothers of Du Pont discovered **Nylon 6,6** [poly(hexamethylene adipamide)] in 1935, while P. Schlack of I.G. Farbenindustrie discovered **Nylon 6** [poly(caprolactam)] in 1937–38. Poly(ethylene terephthalate) (polyester) was first made in England by J.R. Whinfield and J.T. Dickson of Calico Printers. Poly(acrylonitrile) fibre was developed by Du Pont in 1945; polypropylene was patented by Ziegler and Natta in 1954; poly(vinyl alcohol) fibre was produced in 1957, followed by polyurethane elastomeric fibre in 1958.

The development of synthetic fibres is summarised in **four phases**:

| Phase | Period | Development |
|---|---|---|
| Phase 1 | 1935–1950 | Development of Nylon and other fibre-forming polymers |
| Phase 2 | 1950–1960 | Development and commercialisation of [major synthetic fibre types — polyester, acrylic, etc.] |
| Phase 3 | 1960–1970 | Development of second-generation [modified/speciality] fibres |
| Phase 4 | (continuing) | [Further modification / high-performance fibre development] |

*(Note: rows for Phase 2–4 were only partially legible in the scan; the period boundaries and headline theme of each phase are as transcribed above.)*

### Essential (Primary) Properties of an Ideal Textile Fibre

The book identifies the primary/essential properties that any textile fibre must possess, discussed in sequence:

1. **Adequate strength** — "fabrics ... break when force is applied on them." The relevant strength measures cited are tensile strength, bending strength and bursting strength.
2. **Sufficient length in relation to fineness (staple length / spinning quality)** — length is used to express fibre dimension. The two most important fibres, cotton and wool, are available in short (staple) lengths, ranging typically from about **1.5 cm to 5 cm** for shorter varieties up to **≈40 cm** for man-made staple; staple length must match processing machinery, and the fabric must be durable enough for repeated use.
3. **Elasticity (elastic recovery)** — the ability of the material to recover after being deformed by an applied force. Example given: if 1000 cm of yarn is stretched to 1050 cm under load and returns fully to 1000 cm after the load is removed, the fibre has **100% elastic recovery**; if it only recovers to 1010 cm, the elastic recovery is described as about **80%**, while the permanent elongation is 1%. Elastic recovery is influenced by the extent of stretch, the duration the material is held stretched, and the recovery time.
4. **Uniformity** — limited variation in length and diameter from fibre to fibre, ensuring uniformity in yarn and fabric.
5. **Spinnability** — the individual fibres must have sufficient strength and cohesiveness (frictional cohesion) to be twisted/drawn into a continuous yarn; generally, the finer and more uniform the fibre, the better its spinnability, aided by natural fibre surface features (e.g. scales, convolutions) that increase inter-fibre friction and prevent slippage.

The text notes that for man-made/synthetic fibres many of these "primary" characteristics can be engineered into the fibre; hence for synthetic fibres, "primary properties" are commonly redefined in terms of **chemical composition, molecular structure, fibre length and fineness**, which are controllable at the manufacturing stage.

---

## Topic ii) Classification of Textile Fibres — Vegetable, Animal, Mineral, Regenerated and Synthetic

* **Chapter:** 1 – Introduction
* **Page Number(s):** Book p. 18 (classification chart) and pp. 20–23 (sources of fibres); PDF pages 18, 21–24
* **Extracted Content:**

The book presents a **classification tree** of textile fibres (Fig., book p. 18), reproduced below as transcribed from the scan:

```
                                   TEXTILE FIBRES
                    ______________________|______________________
                   |                                              |
             NATURAL FIBRES                                MAN-MADE FIBRES
        ___________|______________                    ___________|___________
       |        |          |                          |                       |
   VEGETABLE  ANIMAL    MINERAL                  REGENERATED               SYNTHETIC
   (Cellulosic) (Protein/                          FIBRES                    FIBRES
       |        hair, silk)                     (from natural            (Polyamides,
   ____|_____      |                            polymer sources)          Polyesters,
  |   |  |   |   Wool/hair   Silk (secretion)   Cellulose sources:        Polyolefins,
 Seed Bast Leaf Fruit  fibres                    Viscose, Cupra-          Polyvinyls,
 hair fibres fibres fibres  (mohair etc.)         mmonium, Acetate,       Polyurethanes)
  |    |    |    |                                Tricel/Polynosic         
Cotton Jute Sisal Coir                            Protein sources:
Kapok  Hemp Pine-  Coconut                        Casein, Alginate
       Linen apple                                    
                                                                        INORGANIC FIBRES
                                                                     (Glass, Metal, Carbon etc.)
```

*(The original figure lists, under "Natural fibres → Vegetable," the sub-groups Seed-hair fibres [Cotton, Kapok], Bast fibres [Jute, Hemp, Linen/Flax], Leaf fibres [Sisal, Pineapple], and Fruit fibres [Coir]; under "Animal," Wool/hair fibres (from sheep, mohair, etc.) and Silk; under "Man-made → Regenerated," fibres from vegetable (cellulose) sources — viscose, cuprammonium, polynosic — and from animal/vegetable protein sources — casein, alginate; and under "Man-made → Synthetic," Polyamides, Polyesters, Polyolefins, Polyvinyls and Polyurethanes; a separate "Inorganic" category is also listed.)*

### Sources of Fibres (narrative classification)

*"All fibres are broadly classified into natural, regenerated, or synthetic. The natural fibres are vegetable, animal or mineral in origin. Also, there are manufactured fibres, which are produced chemically from vegetable sources or animal sources. The synthetic fibres are manufactured from petroleum or coal-tar sources."*

**Sources of cellulosic (vegetable) fibres:** Nature uses fibres as a strength-providing "skeleton" in plants; bundles of fibres are bound by natural gums/resins and run through roots, stems, fruits and leaves. These are associated with varying amounts of lignin, pectin, hemicelluloses, gums, waxes and colouring matter (the total carbohydrate material is termed **holocellulose**). Fibres are classified by the plant part they come from:
- **Seed-hair fibres** (e.g. cotton) — grow from the seed epidermis.
- **Bast fibres** (e.g. jute, flax, hemp, ramie) — from the stem/bark, bound by pectic/gummy substances (4–12% non-cellulosic material), making purification relatively simple.
- **Leaf fibres** (e.g. sisal, pineapple) — run the full length of the leaf, embedded in leaf tissue, separated by "decortication" (scraping).
- **Husk/Fruit fibres** (e.g. coconut/coir, betelnut, palmnut) — from the husk protecting the fruit, extracted by retting.

**Sources of cellulose (non-fibrous forms):** **Wood** is the most widely used cellulosic raw material (hard wood and soft wood types); cellulose is extracted from wood chips chiefly by three chemical processes — **(a) the sulphite process, (b) the sulphate process, and (c) the soda process** (soda process generally used for hardwoods). Other cellulose sources cited include grasses and straws (e.g. sabai grass), and various plant wastes/shells.

**Sources of protein (animal) fibres:** Proteins occur naturally in plants and animals; protein fibres are generally hair or secretion products. **Wool** is defined as the protein fibre grown as the fleece of domestic sheep. Other named hair fibres: **(a) Wool** – from sheep, **(b)** [Mohair – from Angora goat], **(c) Cashmere** – from cashmere goat, **(d) Camel hair** – from camel, **(e) Rabbit fur** – from rabbit, **(f) Horse hair** – from horse, **(g) Alpaca/Llama** – from llama. A second type of protein fibre, **silk**, is produced from the secretion of caterpillar larvae during cocoon formation; silk may be **domesticated** (mulberry) or **wild** (tussah, endi, eri, muga, fagara are named as important wild silks).

Of vegetable/animal proteins used to make **regenerated protein fibres**, the book notes only three plant proteins — **zein, arachin and glycinin** — and one animal protein, **casein**, are commercially exploited.

**Sources of synthetic fibres:** *"The main sources for formation of synthetic fibres are: (1) Petroleum, (2) natural gas deposits and (3) coal."* Petroleum contains liquid and solid hydrocarbons (paraffins, naphthenes, aromatics) that serve as raw materials for monomer synthesis; natural gas (rich in simple paraffins such as methane) and coal (via coal-gas/coke manufacture, yielding benzene and its derivatives from the middle-oil fraction of coal tar, and phenol) are the other two principal feed-stocks.

**Table (reconstructed) — Chemicals, Monomers and resulting Polymers (Chapter 2, p. 26–27):**

| Feedstock | Chemical/Intermediate | Monomer | Resulting Polymer |
|---|---|---|---|
| Petroleum / Natural gas | Ethane → Ethylene | Ethylene | Polyethylene |
| Petroleum | Propylene | Propylene | Polypropylene |
| Petroleum | — | Vinyl chloride | Poly(vinyl chloride) |
| Petroleum | — | Vinyl acetate | Poly(vinyl acetate) / Poly(vinyl alcohol) |
| Petroleum | — | Acrylonitrile | Poly(acrylonitrile) |
| Petroleum/coal | Caprolactam | Caprolactam | Polyamide 6 (Nylon 6) |
| Petroleum/coal | Adipic acid + Hexamethylene diamine | AH salt | Polyamide 6,6 (Nylon 6,6) |
| Petroleum | Ethylene glycol + Terephthalic acid (or DMT) | — | Poly(ethylene terephthalate) (Polyester) |

---

## Topic iii) Microscopic, Physical and Chemical Test Methods for Fibre Identification

* **Chapter:** 20 – Identification and Applications of Fibres
* **Page Number(s):** Book pp. 346–360 (PDF pages 358–370)
* **Extracted Content:**

The chapter opens: *"Fibres broadly can be classified into organic and inorganic … most of the fibre-forming polymers are of organic origin."* Because fibre-forming polymers share broadly similar behaviours (owing to their large-molecule/macromolecular nature) yet each polymer type has characteristic reactivity of its functional groups, a polymer/fibre "can be identified by normal fractional [chemical] tests." The chapter classifies identification methods into two broad groups:

**Simple tests** (no special equipment needed):
- Feeling test
- Burning test
- Staining test
- (Simple) Chemical/solubility test

**Technical tests** (require special equipment or chemicals):
- Microscope test
- Density measurement
- Chemical test (detailed/instrumental)

### 1. Feeling Test
The fibre's "hand" is assessed by touch: cool or warm feel, and smooth or rough/harsh surface — used as a first, rough indicator of fibre type (e.g. cool-and-smooth feel is characteristic of some fibres, warm/rough of others).

### 2. Burning Test
A small sample is brought near/into a small luminous flame; the burning behaviour, the odour given off, and the nature of the residual ash are all diagnostic. **Table — Burning characteristics of fibres (reconstructed from Table 20.2):**

| Fibre | Burning behaviour |
|---|---|
| **Cellulosic fibres** (cotton, linen, jute, viscose rayon, etc.) | Burn readily/quickly, continue burning after removal from flame, with little ash; smell of burning paper. |
| **Wool** | Burns slowly, self-extinguishing; flame is yellow-orange with a blue/purple-edged base; ash/residue is dark, crisp, and can be crushed easily between the fingers; odour like burning hair/feather. |
| **Silk** | Burns readily with a light sizzle; flame is orange-yellow with blue-grey smoke; the fibre sparkles, swells and chars; odour like burning hair. |
| **[Acetate/other cellulose-ester fibres]** | Burns with grey smoke; odour like burning [vinegar/chemical]; melts as it burns. |
| **Nylon (polyamide)** | Fibre softens and melts before burning; burns with a blue flame and yellowish-orange tip; forms a hard, irregular bead/residue on cooling. |
| **Polyester** | Sample fuses/shrinks away from the flame, then melts and burns vigorously, forming a hard, dark, brittle residue/bead. |
| **Glass fibre** | Does not burn; glows when heated, giving little or no flame colour, or a faint yellow (sodium) flame. |

### 3. Microscope Test
Longitudinal and cross-sectional views of fibres are examined under a microscope; the book includes plates (Fig. 20.1 and related figures, book pp. ~348–356) showing the characteristic microscopic appearance of the different fibre types (e.g., cotton's flat, twisted, ribbon-like convoluted shape; wool's scaly cuticle; silk's smooth, triangular/wedge cross-section; synthetic fibres' typically smooth, circular or engineered cross-sections). *(These plates are photographic/line-drawing figures in the scan and could not be reproduced here; see PDF pp. 361–368 for the originals.)*

### 4. Density Measurement
*"A rough estimation of density can also identify the fibres."* The fibre is placed in a liquid (or liquid mixture) of known density: if the fibre's density is greater than that of the liquid it will sink; if less, it will float. **Table — Density of common fibres (Table 20.4):**

| Fibre | Density (g/cc) |
|---|---|
| Cotton and other cellulosic fibres | 1.54 |
| Acetate fibre | 1.32 |
| Silk | 1.32 |
| Wool | 1.32 |
| Nylon | 1.14 |
| Polyester | 1.38 |
| Acrylic | [~1.17, value not clearly legible in scan] |

*(Note: Chapter 10's own data for viscose rayon separately states its density as 1.52 g/cc, "same as that of cotton" — see Topic (vi) below.)*

### 5. Staining Test
Fibres of different chemical types absorb different stains/dyes and hence show different colours when treated with a standard staining chemical — described in the text as "solution A," made up as a diluted reagent (roughly a 1:5 dilution with water). Cellulosic fibres, protein fibres and man-made fibres each give characteristically different colorations (e.g., a specific blue coloration is cited for one fibre class), allowing quick differentiation (Table 20.5 in the original — individual colour codes were not fully legible in the scan).

### 6. Chemical (Solubility) Test
A fibre is identified from its characteristic solubility/insolubility in a panel of chemical reagents at specified concentration and temperature. **Table — Solubility test reagents (reconstructed from the chapter's solubility table):**

| Reagent (approx. conditions) | Soluble | Insoluble |
|---|---|---|
| Conc. HCl / cold | Wool and Silk (soluble) | Cellulosics, Acetate, Nylon, etc. (insoluble) |
| 70% Sulphuric acid (1:1), 25°C | Cellulosics (cotton, viscose) soluble | Acetate insoluble |
| Formic acid (1:1) at 25°C | Nylon 6,6 soluble | Polyester, acrylics, etc. insoluble |
| [Other reagents: acetone, m-cresol, DMF, etc.] | Acetate soluble in acetone; Polyester soluble in hot m-cresol; PAN soluble in DMF | — |

*(The full reagent/temperature grid (Table 20.5/20.6 in the original) spans several reagents; only the clearly legible rows are reproduced above. The original PDF pages 369–370 should be consulted for the complete grid.)*

### Applications of Fibres and Textiles (context, same chapter)
The chapter closes by classifying textile end-uses into four broad categories: **(1) Apparel textiles** (menswear, womenswear, childrenswear, sportswear); **(2) Household/interior textiles** (bedding, quilts, curtains, upholstery, carpets); and **(3) Technical textiles**, further divided into six application groups — **Mobile textiles** (automobile/aerospace insulation, upholstery), **Geo-textiles**, **Industrial textiles**, **Construction textiles**, **Medical textiles** (surgical/hospital products, bandaging, artificial blood vessels, masks) and **Safety/protective textiles** (bullet-proof materials, chemical-protection clothing); and further sub-classified by twelve application areas (air & space, agriculture, building/construction, clothing, home, industrial, marine, medical, packaging, personal protection, sport & leisure, transport, etc.).

---

## Topic iv) Physical, Chemical Properties and Uses of Vegetable Fibres — Cotton, Jute, Linen

### (A) COTTON

* **Chapter:** 5 – Cotton
* **Page Number(s):** Book pp. 70–90 (PDF pages 84–104)
* **Extracted Content:**

**Cultivation & botanical origin:** Cotton is now cultivated in nearly every country having a suitable climate; the major producers named are USA, India, China, Brazil, Egypt and Mexico, with cotton also grown in Turkey, Argentina, Spain, Pakistan, Syria, Peru, Greece and Colombia. Cotton grows well in **tropical and sub-tropical regions lying between 30°N and 35°S of the equator**. Planting occurs in March–April; ridges are formed with 1.5–2.0 m spacing; flowering occurs around June, and bolls reach full size by August. **Yield per acre** is cited as approximately **320 kg worldwide**, versus only about **170 kg in India**. Botanically, cotton is a **seed-hair fibre** — a single-cell overgrowth from the epidermis of the cotton seed — and its fibre development on the seed occurs in **two phases**: (1) an initial ~25-day unidirectional elongation phase forming a hollow tube bounded by a primary wall and cuticle, and (2) a ~35–40 day thickening phase in which the secondary wall is deposited layer by layer on the inside of the primary wall, progressively reducing the lumen.

**Botanical/commercial classification:** Four cultivated species are named: *Gossypium arboreum* (India), *G. herbaceum* (Middle East, Egypt), *G. barbadense* (Peru, Egypt, Sea Islands), and *G. hirsutum* (America, West Indies). Commercially, cotton is classified into six types by source/staple length: **(a) Sea Island cotton** — long, fine, soft, silky, most uniform, light creamy tint (from *G. barbadense*, grown in the USA — Carolina, Georgia, Florida); **(b) Egyptian cotton** — fine, soft, silky, similar to Sea Island; **(c) Brazilian cotton**; **(d) American (Upland) cotton**; **(e) Indian cotton**; **(f) a sixth named type (text partly illegible in scan)** — described as the poorest quality, with a staple length of only around 1.5–2.0 cm.

**Grading** is based on three factors: **(a) colour** (White, Light Spotted, Spotted, Tinged, Yellow Stained, Light Grey, Grey), **(b) trash content** (leaf, stem, hulls, bark, seed, sand, oil, dust — grading such as Strict Good Middling, Good Ordinary, etc., with "+" suffix for extra-clean lots), and **(c) ginning quality**.

**Morphological structure:** Each flower produces 20–25 seeds enclosed in a green boll; on splitting of the mature boll and evaporation of internal moisture, the tubular fibre collapses, developing the characteristic **twisted, ribbon-like convolutions**. The fibre wall has three layers: **(a) Cuticle** (waxy outer coating), **(b) Primary wall** — built of randomly-oriented cellulose fibrils spiralling at ~70° to the fibre axis, about 0.1–0.2 micron thick, and **(c) Secondary wall** — concentric spiral cellulose layers (outer layers at ~20–30° spiral angle, becoming finer with ~20–45° in subsequent layers), forming the bulk of the fibre's weight; overall fibre diameter is about 15–20 microns. **Convolutions** arise to relieve internal stress during drying/collapse of the fibre and can number many reversals along the fibre length; convolution pitch depends on ribbon width and wall thickness.

**Chemical composition (Table 5.1, dry mature cotton):**

| Component | % |
|---|---|
| Cellulose | 88.0 – 97.0 |
| Protein | 1.0 – 2.0 |
| Oil and wax | 0.4 – 1.5 |
| Pectins | 0.4 – 1.5 |
| Minerals | 0.7 – 1.6 |
| Others | 0.5 – 8.0 |

Native cotton cellulose contains about **12,000–18,000 glucose residues** per chain, uncombined with lignin. Pectic substances (~0.4–1.5%) are largely **calcium, magnesium and iron pectates**, insoluble in water but soluble/removable in alkali boiling. Mineral matter (0.7–1.6%) is largely surface-deposited and can be substantially reduced simply by boiling the fibre in water.

**Physical properties:**
- **Staple length:** varies from about **1 cm to 6 cm** across commercial classes (Sea Island longest, at ~5 cm and more; short Indian varieties around 1.5–2.5 cm).
- **Fineness/maturity:** cotton fibre is not perfectly uniform; longer-staple cottons tend to be finer; immature fibre shows thinner walls and a lower maturity ratio.
- **Porosity:** cotton exhibits capillary/porous effects; roughly 70% or more of the fibre volume is occupied by densely packed crystalline/amorphous cellulose, the remainder being pore space; finer cottons are generally more porous than coarse varieties; the central lumen is typically small.
- **Lustre:** cotton has only moderate natural lustre due to its convoluted, non-smooth surface.
- **Density:** ~1.54 g/cc.
- **Moisture:** Cotton is hygroscopic; each anhydroglucose unit carries three hydroxyl groups, but due to structural imperfections roughly only one out of three is accessible for water absorption. Standard moisture regain is about **7–8.5%** at 65% RH/21°C, rising to roughly **20–25%** at 95–100% RH.
- **Tensile strength / elongation:** breaking elongation is about **5–10%** (typically 6–8%); elastic modulus of the fibre is roughly **500–525 g·wt/tex**; fibrils spiral at about 20–30° to the fibre axis, which influences extensibility.

**Chemical properties:**
- **Action of heat:** cotton ignites easily and burns readily like paper, continuing to smoulder after flame removal. Drying above ~93°C risks tendering (formation of oxycellulose in presence of O₂); scorching begins around 170°C; in the absence of air, thermal degradation proceeds by dehydration and by C–O bond scission (weaker than C–C bonds) within the anhydroglucose ring, giving levoglucosan-type degradation products.
- **Action of light:** prolonged sunlight exposure oxidises cellulose to oxycellulose, causing tendering, similar in effect to heat ageing.
- **Action of acids:** dilute mineral acids at cold temperature cause little damage, but hot/concentrated mineral acids hydrolyse cellulose to hydrocellulose and ultimately to soluble sugars; nitric acid's oxidising action produces oxycellulose on prolonged exposure, eventually degrading to oxalic acid.
- **Action of alkalis:** cotton is notably resistant to alkali — dilute sodium carbonate has essentially no effect (absent air); even fairly concentrated NaOH (2–7%) can be boiled without tendering in the absence of air, though oxycellulose forms if air/oxygen is present. **Mercerisation** — treatment with strong (~13% or higher) NaOH with or without tension — produces shrinkage, a silky lustre, improved tensile strength and improved dye affinity; maximum "differential swelling" is associated with about 13% NaOH.
- **Micro-organism resistance:** cotton is attacked by mildew-causing fungi, which discolour, rot and weaken the fibre; bacteria can cause underwater ("wet") rotting.

**Modification of cotton:** the book lists cotton's inherent drawbacks as **(a)** poor solubility in common solvents (restricting chemical modification), **(b)** poor crease resistance, **(c)** lack of thermoplasticity (preventing heat-setting), and **(d)** poor dimensional stability during laundering/ironing. Chemical modification routes described include: **acetylation**, **cyanoethylation** (reaction with acrylonitrile after alkali impregnation, improving rot/acid/abrasion resistance and dyeability), **carboxymethylation**, **cross-linking with formaldehyde-type resins** (crease-resistant, low-shrink finishes via methylene-ether cross-links preferentially in the amorphous regions), and **graft copolymerisation** with vinyl/acrylic monomers.

**Uses:** Cotton is the world's most widely used natural textile fibre — apparel, household textiles (bedding, towels), and industrial fabrics; crease-resistant and flame-retardant chemically-modified cotton is used where those specific properties are required (per the "Modification" section above).

---

### (B) JUTE

* **Chapter:** 6 – Vegetable Fibres (bast-fibre section)
* **Page Number(s):** Book pp. ~94–99 (PDF pages 108–112)
* **Extracted Content:**

**Introduction:** *"Jute occupies second place, next to cotton, in the world's [textile fibre] production."* Around **83% of the world's jute is grown** in the Indian subcontinent (India and Bangladesh). The botanical names of the source plants are ***Corchorus capsularis*** and ***Corchorus olitorius***.

**Cultivation:** Jute requires a hot, humid climate (roughly 34°C with high humidity), grown mainly in West Bengal, Orissa, Assam and Bihar. Sowing occurs in **February–March**, with germination in about 6–15 days depending on soil moisture. The plant grows to a height of about **8–17 feet**, maturing in roughly **100–130 days** from sowing. When mature, small yellow flowers appear with a characteristic sweet smell, and the stalks are cut for retting.

**Retting and fibre extraction (Fig. 6.1, "Anatomy of jute stem"):** After the non-cellulosic material is removed by retting, only the ultimate fibre cells remain of textile value. Retting is a microbiological process, and the resulting fibre's colour, strength and lustre depend on the retting method and conditions (temperature, water quality, presence of retting micro-organisms, pH, duration). Methods described:
- **Stagnant water retting:** stalk bundles are immersed in closed stagnant water; after a few days of fermentation and CO₂ generation inside the stalk tissue, the bark loosens, colour changes to yellow, and after proper retting the fibre is washed clean; typical duration **10–20 days**.
- **Running water retting:** similar principle but in flowing water, typically **20–30 days**.
- **Dew retting:** exposure to dew/moisture in open fields.
- **Chemical retting:** boiling in dilute (approx. 1%) sodium hydroxide or dilute sulphuric acid at boiling temperature for a few hours, hydrolysing/degrading the lignin, pectin and hemicellulose binding the fibre bundles; **duration only about 4–8 hours**, much faster than biological retting.

After retting, mechanical **"crushing"** breaks the woody core into small pieces, removed by **"stripping."** Clean fibre bundles are then separated by **hackling** (manual or mechanical combing).

**Physical properties:** The smallest commercial unit of raw jute is called a **"reed."** Reed length varies from **1 m to 4.5 m** depending on grade. Denier ranges from **6 to 50** (average ≈18–20 denier); fibre diameter is about **6–20 microns**; cross-section is **polygonal with a wide lumen**. Jute is hygroscopic, with a standard moisture regain of about **13%**. Tensile strength is about **5–8 g/den**, and density is **1.48 g/cc**.

**Chemical properties:** Like other cellulosics, jute is not significantly affected by moderate heat, but prolonged heating degrades the fibre (colour progressively changes light-brown → deep-brown → black). Light exposure causes tendering with a colour shift from yellow to brown/deep brown. Jute fibre itself is mildly **acidic** (aqueous extract pH ≈ 5.5–6.2). Dilute cold acids have little effect (and may even brighten the fibre), but hot/concentrated acids degrade it; dilute alkalis have little effect but concentrated hot alkalis degrade it; strong oxidising agents attack the fibre while mild ones have little effect.

**Chemical composition (Table 6.1, dry basis):** Cellulose ≈ 71–75%, Hemicellulose ≈ 12–13%, Lignin ≈ 13%, with smaller pectin, wax and ash fractions — this relatively high lignin content accounts for jute's characteristic stiffness compared with cotton or flax.

**Uses:** Jute is widely used for sacking, hessian cloth, carpet backing, ropes and cordage, and coarse household/industrial textile applications (consistent with the book's broader vegetable-fibre "Uses" discussion, which groups the bast fibres together for household and industrial end-uses — see Flax below).

---

### (C) LINEN / FLAX

* **Chapter:** 6 – Vegetable Fibres (bast-fibre section)
* **Page Number(s):** Book pp. ~99–101 (PDF pages 113–115)
* **Extracted Content:**

**Introduction:** Flax is a bast fibre obtained from the plant ***Linum usitatissimum***, cultivated in cold and temperate countries. Major flax-growing countries named include the **[erstwhile] U.S.S.R., Argentina, Brazil, France** and other temperate regions.

**Cultivation:** Like jute, flax is an annual plant, grown in moist, cold conditions. The plant grows to about **170 cm in height** and **1.5 cm diameter**; maturity is indicated by the stalk's colour changing from green to yellowish-brown. Harvesting timing affects fibre quality: **(i)** harvesting when flowering is almost over gives the finest fibre but poor yield; **(ii)** harvesting is better delayed until the seed pods have ripened for improved yield, though slightly coarser fibre results. After pulling, the plants are laid in the open field (or bundled) for retting; **"rippling"** — continuous beating/combing of the dried stalks — removes the seed bolls before retting.

**Retting (Table 6.3, Duration of retting of flax fibres):**

| Retting process | Duration |
|---|---|
| Dew retting | 10 – 20 days |
| Stagnant water retting | 30 – 40 days |
| Running water retting | 20 – 30 days |
| Chemical retting | 4 – 8 hrs |

The chemistry of flax retting differs somewhat from jute retting because of differences in hemicellulose/pectin composition; dilute alkali or acid can also be used for chemical retting. After retting, bundles must be dried and stored so the fibre becomes stronger and the woody core can be more easily removed.

**Physical properties:** Fibres are **polygonal to round in cross-section with a small lumen** (typical of bast fibres). Chemical composition (from Table 6.1): Cellulose ≈ 71–72%, Hemicellulose ≈ 18–19%, Lignin ≈ 2%, with small pectin/wax/ash fractions — flax has a notably lower lignin content than jute, correlating with its greater softness and fineness relative to jute.

**Uses:** *"These fibres are used for household [linens/fabrics] and certain industrial applications [such as] fire-hoses."*

---

## Topic v) Physical, Chemical Properties and Uses of Animal Fibres — Wool, Silk

### (A) SILK

* **Chapter:** 8 – Silk
* **Page Number(s):** Book pp. 117–134 (PDF pages 131–146)
* **Extracted Content:**

**Nature of silk:** *"Silk is a structureless secretion in the form of a cocoon consisting [of a continuous] filament, the length of which varies from species to species."* Two varieties are named: **domesticated (mulberry) silk** and **wild silk**. Domesticated silk comes from the caterpillar of the moth genus ***Bombyx*** (*Bombyx mori*), which feeds on mulberry leaves.

**Sericulture / life-cycle:** Eggs are hatched in incubating rooms at **20–29°C**; a female moth lays about **500 eggs**. Eggs are of two kinds — those retained for reproduction and those raised for cocoon production. After being kept in cold storage, egg-sheets are warmed to about **25–27°C**; incubation takes **8–10 days**. The hatched caterpillar initially weighs very little and is about 2–3 mm long; over **20–30 days** of feeding on mulberry leaves it increases enormously in size and weight (the text states an increase of almost **ten-thousand-fold** during growth). When growth is complete, the worm stops eating, changes colour from greenish-white to creamy, and is transferred to a special frame/tray where it spins its cocoon, secreting a continuous silk filament around itself (pupation). The adult moth is whitish-grey with a soft body and rudimentary wings and lives only **3–4 days**.

**Production of raw silk (reeling):** Good, undamaged cocoons are selected (irregular, flossy, thin/double cocoons are rejected). Cocoons are **cooked/boiled** in soft water to swell and soften the sericin gum, using **(a) open-pan (single basin), (b) three-pan, or (c) pressurised cocoon-boiling** methods. Reeling follows, involving brushing (to find the filament end), end-picking, casting, and gathering several filament ends together (Fig. 8.2, reeling machine — cocoons float in a hot-water bath while the reeler draws off the filament through a tension guide and yarn guide, continuously topping up with fresh cocoons as each is exhausted). **Croissure** (crossing of the threads) improves cohesion via twisting; **French reeling** twists only two threads, while the **Italian system** twists 4–5 threads together for higher cohesion. Three reeling systems are named: **(1) Charkha reeling** (handloom, Italian-type single-basin process), **(2) Cottage basin system** (cooking and reeling in separate basins), and **(3) Filature system** (larger-scale mechanised reeling).

**Throwing:** the reeled silk is twisted ("thrown") further — different silk yarns (organzine, tram, crepe) receive different twist levels (of the order of **10–20+ turns per cm**, according to type).

**Wild silk:** varieties named include **Tussar, Muga, Eri (Endi), Fagara**. Wild silk cocoons are larger, darker, and have thicker filaments than mulberry silk, and contain more gum (including a complex calcium compound that is harder to remove); wild-silk fibres are also spun (like cotton) rather than always reeled. Distinguishing features versus mulberry silk: **(a)** duller lustre; **(b)** larger, darker cocoons with thicker filaments; **(c)** higher strength/durability; **(d)** greater resistance to moisture; **(e)** natural colour from the leaf pigments the larvae feed on (often more attractive than dyed mulberry silk); **(f)** cheaper, since the wild caterpillars feed and are reared with less intensive care.

**Spun silk / waste silk:** pierced, damaged, or broken cocoons and processing waste are cleaned, carded and spun into **"spun silk"** (also called "waste silk"); **Schappe silk** is obtained from the outer/inner cocoon layers or pierced cocoons, while **Bourette silk** ("silk noils") comes from waste generated while picking, carding, combing and spinning Schappe silk; silk processed via handloom/charkha is called **"charkha silk."**

**Morphological structure:** Raw silk fibre (fibroin coated with sericin) shows a "corn"/rod-like layered structure with transverse markings, folds and irregular lumps under the microscope, the sericin coating giving the raw fibre a rough surface; once the gum is removed (degummed silk), individual filaments show smooth surfaces with distinct longitudinal striations, and in cross-section the fibroin filament is typically **wedge-shaped/triangular** (giving silk its characteristic sparkle/lustre from internal reflection).

**Chemical composition (Table 8.1, approximate ranges across mulberry, tassar, muga silk):**

| Component | Mulberry Silk | Tassar Silk | Muga Silk |
|---|---|---|---|
| Fibroin | 70–80% | 80–90% | [similar range] |
| Sericin | ~20–30% | ~10–20% | [similar range] |
| Wax, minerals, other impurities | ~1–3% each | ~3–5% | ~3–5% |

Fibroin and sericin are both proteins built from similar amino acids but in different proportions. Fibroin's major amino acids (approximate %): **Glycine 20–30%, Alanine 35–40%, Serine 10–15%, Tyrosine 8–10%**, plus smaller amounts of Arginine, Threonine and Lysine. Sericin's amino-acid profile differs — richer in Serine, Lysine, Aspartic acid and Glutamic acid, with smaller Glycine content than fibroin; sericin is fully solubilised in acid solution at pH ≈ 2.5 or alkali solution at pH ≈ 9.5, which underlies the degumming process. Yellow silk's colour derives from the natural yellow pigment of mulberry leaves (as opposed to chlorophyll, which colours "green" silks).

**Chemical structure:** Fibroin is a polypeptide that, in the liquid (pre-spun) state, has a helical/coiled conformation which straightens into an **extended-chain, anti-parallel pleated-sheet** structure once spun and drawn — analogous in principle to wool's β-keratin form. The crystalline region (roughly **20–25%** of the fibre) is composed mainly of the smaller glycine and alanine residues (able to pack closely), while bulkier residues (tyrosine, lysine, arginine) are excluded to the amorphous regions. Adjacent anti-parallel chains are linked by **hydrogen bonds** between CO and NH groups and by van der Waals forces, forming the pleated-sheet arrangement (repeat distance ≈ 7.0–7.3 Å; sheet spacing ≈ 9.2–10.6 Å depending on side-chain bulk).

**Chemical processing — Degumming:** Removal of sericin ("degumming") is necessary because undegummed silk is stiff, dull, and harsh-handling. Sericin, being concentrated on the fibre surface, is comparatively easy to hydrolyse/extract. Methods: **(1)** extraction with hot water alone (safest, minimal fibre damage, typically 100–130°C for 30 min–4 hours), **(2)** treatment with alkali (e.g. **trisodium phosphate + soap at the boil**, 30 min–1 hour), **(3)** enzymatic digestion, or **(4)** treatment with dilute acid (pH < 3 also removes sericin). "**Weighting**" of silk (to restore/increase weight lost during degumming) is also described — treatment with **stannic chloride**, followed by phosphate and sodium silicate treatments, builds up mineral weighting in a controlled, staged manner.

**Physical properties:**
- **Fineness/denier:** raw (gummed) silk denier is higher than that of degummed silk (sericin removal reduces weight/denier).
- **Density:** silk fibre has a density of about **1.25 g/cc raw, and around 1.32–1.34 g/cc degummed** (values as legible in the source table).
- **Elasticity:** silk requires relatively high tension to stretch — as much as **0.90 g tension per denier**, compared with wool's **0.32 g tension per denier**, indicating silk is comparatively less elastic/more resistant to initial stretch than wool.
- **Moisture regain:** silk is "about midway between cotton and wool" in hygroscopicity; raw silk regain is about **11%**, rising after degumming.
- **Electrical properties:** silk is a poor conductor and readily builds up static charge by friction, which is dissipated at high humidity.
- **Scroop:** the characteristic "cracking" sound heard when silk is squeezed/rubbed — not an inherent fibre property but can be developed by treating (scrooping) with dilute acetic or [other] acid.
- **Thermal behaviour:** silk can be heated to about **140°C** without decomposition risk, but rapidly disintegrates above roughly 170°C; hence silk cannot be ironed at very high temperatures.

**Chemical properties:**
- **Action of water:** silk readily absorbs water (raw silk can absorb up to ~25% of its own weight); prolonged hot-water contact during reeling/degumming affects the fibre's structure and lustre.
- **Action of acids:** silk readily absorbs dilute acids (which increases its scroop); concentrated acids cause more damage. Silk has a strong affinity for tannic acid, which is readily removed with water. Treatment for one minute with nitric acid (density ≈ 1.33) at 45°C imparts a yellow colour that is wash-fast and light-fast (pure nitric acid alone does not give this colour effect); brief hot-acid exposure can also affect lustre.
- **Action of alkalis:** silk is less sensitive to dilute alkalis than acids, but strong alkalis can degrade/dissolve the fibre.
- **Photochemical action:** the extent to which silk is weakened by light exposure depends on pH — stability is greatest around **pH 10**, decreasing above pH 11 and below this optimum range.
- **Action of metallic salts:** silk exhibits strong affinity for many metallic mordant salts, absorbing and fixing them (used for "weighting" and dyeing); some salts (e.g. sodium chloride) have little effect, while others can cause tendering.

**Uses:** *(General context from the chapter and trade knowledge, given the text's emphasis on lustre, drape and strength.)* Silk is prized for high-value apparel (sarees, ties, scarves, eveningwear), fine furnishings and specialty industrial uses (parachute fabric historically, surgical sutures) owing to its combination of strength, fine lustre and dyeability; spun/waste silk grades are used in lower-cost silk fabrics and blends.

---

### (B) WOOL

* **Chapter:** 9 – Wool
* **Page Number(s):** Book pp. 135–153 (PDF pages 146–163)
* **Extracted Content:**

**Introduction:** *"Wool is the [most widely used] animal fibre ..."* wool is produced across many temperate/cold countries; **the major production of wool is [from Australia]**, with significant amounts also coming from other cold countries. *"All other hair fibres lack in [commercial importance in] the textile field, [rather] wool ... [is dominant]."*

**Wool production & grading:** The commercial **grading of wool** depends on **fineness (diameter), length and crimp**. Broad classes are **(1) Fine, (2) Medium, and (3) Coarse** wool:
- **Fine wool** — from Merino and Rambouillet-type sheep; average staple length **~3.2–10 cm**; average diameter **~10–[?] microns** (fine fibre); used for **60s to 90s** count yarn.
- **Medium wool** — from crossbred sheep; suited for **36s to 60s** yarn; length **~5–20 cm**; diameter **~20–40 microns**.
- **Coarse (long) wool** — from breeds such as **Cotswold, Leicester and Romney Marsh**; length **~10–35.5 cm**; diameter **~35–50 microns**; suited for **35s to 50s** yarn (coarser end used for carpet-grade yarns, up to ~100 microns diameter for the coarsest grades).

**Production of clean wool — "wool sorting":** Raw ("greasy") wool is the natural sheep fleece, containing (besides the fibre itself) **wool wax (grease/lanolin), suint (dried perspiration salts), inorganic dirt (soil/sand) and vegetable matter**. Wool wax and suint are the two chief organic/soluble impurities; sandy/soil particles form the inorganic dirt. Composition varies with sheep breed and body region — wool from the belly/leg region generally contains more organic dirt than back/shoulder wool, and impurity content is often higher near the fibre tip/root end. The overall process of sorting greasy fleece wool by quality into different commercial grades is termed **"wool sorting."**

**Morphological structure (Fig. 9.1):** Wool fibre consists structurally of a **scaly cuticle (outer layer)** and an inner **cortex**. The cuticle is made of overlapping scales pointing toward the fibre tip, forming a protective epidermal layer; scale width is about **36 microns**, scale thickness **0.5–1.0 micron**, and visible scale length about **16 microns**; scale size/density vary along and between fibres — in fine wool a single scale may encircle the whole fibre (giving a "stack of funnels" appearance), while coarser fibres have more scales per circumference. The scaly layer itself has three sub-layers: **epicuticle** (outermost, extremely thin, ~50–250 Å), **exocuticle**, and **endocuticle** (innermost). The **cortex**, forming the main bulk of the fibre, consists of long, slightly flattened, spindle-shaped cells about **80–110 microns long** and roughly **2.5 × 1.2–2.6 microns** in cross-sectional (major/minor) diameter; fibre cross-section is typically circular to elliptical, and the cortex is mainly responsible for the fibre's mechanical (tensile, elastic) properties.

**Chemical composition — Amino acids (Table 9.2):** Wool fibre (keratin) is built from a range of amino acids classified by their side-group (R-group) chemistry: **hydrocarbon-type** (Glycine, Alanine, Valine, Leucine, Iso-leucine), **hydroxyl-type** (Threonine, Tyrosine, Serine), **acidic** (Aspartic acid, Glutamic acid), **basic** (Arginine, Lysine, Histidine), **sulphur-containing** (Cystine, Methionine), and **cyclic/5-membered-ring** (Proline). Wool is noted to be particularly **rich in Cystine**, whose disulphide (–S–S–) cross-links are central to wool's mechanical and chemical properties, and **rich in Arginine**, which contributes basic side groups (capable of forming salt-linkages with acidic side groups such as those of Aspartic/Glutamic acid).

**Chemical structure — Keratin arrangement:** Amino acids condense (via the –COOH and –NH₂ groups) into long polypeptide chains. The long-chain keratin molecule can theoretically adopt: **(a)** a straight, fully-extended zig-zag chain, **(b)** a folded chain (coiled backward/forward in a plane), or **(c)** a coiled/helical chain. Wool keratin is understood to exist mainly in **two forms — α-keratin (coiled/helical, contracted) and β-keratin (fully extended)** — with the α-form as the "resting" state and conversion toward β occurring on stretching. Within a fibril, molecular chains are aligned side-by-side (similar to fibres in a sliver), held together by **hydrogen bonding, salt linkages, and cystine (disulphide) linkages** between adjacent chains. **Salt linkage** forms between the basic side-groups (e.g. from Arginine/Lysine, positively charged as –NH₃⁺) and acidic side-groups (e.g. from Aspartic/Glutamic acid, negatively charged as –COO⁻) of adjacent chains (Fig. 9.4). **Cystine (disulphide) linkage** (Fig. 9.5) covalently cross-links adjacent chains via the characteristic –CH₂–S–S–CH₂– bridge, since cystine is a dicarboxylic, diamino acid capable of linking into two different polypeptide chains.

**Summary of wool protein structure (as stated in the text):**
1. Amino acids are joined together to form a long chain.
2. Side groups of the amino acids project from the main chain.
3. Some side groups are polar (acidic, basic, or containing hydroxyl/amino groups).
4. Some side groups are non-polar (hydrocarbon-type).
5. Adjacent chains are attracted to each other by hydrogen bonds and electrostatic (salt-linkage) forces, in addition to covalent disulphide cross-links.

**Capillary/pore structure:** Capillaries in dry wool are extremely fine (around **6 Å**), too small to admit water molecules directly in the crystalline regions; water instead penetrates the amorphous regions. On water-swelling, pore size in the amorphous/lamellar regions increases to about **40–45 Å** (an increase of roughly 3 Å); methyl alcohol and ethyl [alcohol] produce a similar swelling effect to water.

**Physical properties:**
- **Length:** wool fibre length varies greatly, from about **3.6 cm to 35 cm**, varying by breed and even within the same fleece; wool is classed as **fine (3.2–10 cm), medium (5–20 cm), or coarse (15 cm and above)**; short fibres are used for heavily felted cloths.
- **Fineness:** ranges from about **10 to 70 microns**; fine wool is typically 10–30 microns, carpet-grade wool 20–70 microns.
- **Elasticity:** wool has notably good elastic recovery, described as high compared with other textile fibres; the ability to recover after stretching is good even after repeated stretch cycles.
- **Hygroscopic property:** wool is more hygroscopic than most other textile fibres; it can absorb as much as **25–30% moisture** under very humid conditions, with standard (65% RH) regain around **12–15%**, and at 70–80% RH the regain is proportionately less.
- **Specific gravity:** **1.30–1.32 g/cc**.
- **Lustre:** varies considerably; some wools are highly lustrous, others duller (rough-surfaced) due to atmospheric weathering that partially destroys the scale structure.
- **Colour:** ranges from white to black/brown, depending on breed (specific fine wools noted for particular colour characteristics).
- **Electrical properties:** wool is a poor conductor of electricity (like most natural protein fibres).
- **Thermal properties:** effects of heat are not significant up to about **130°C**; higher/prolonged heat begins to affect the fibre.

**Chemical properties:**
- **Action of dry heat:** prolonged dry heating at 100–105°C over a long period causes the fibre to become harsh and lose strength; in moist air it can rapidly reabsorb moisture and regain some strength; if 100°C is exceeded for prolonged periods the wool decomposes, turns yellow, and evolves NH₃/H₂S.
- **Burning behaviour:** wool gives off an odour like burning hair/feather (nitrogen-containing), and self-extinguishes when removed from the flame, forming a black, charred, knob-like residue at the burnt end — hence wool is described as inherently **fire-resistant**; vapour from burning wool turns moist red litmus paper blue (alkaline reaction).
- **Effects of water and steam:** wool changes shape and dye affinity on exposure to water/steam, with or without tension; boiling water at 130–150°C makes wool partially soluble; wool swells up to about 10% in size in cold/hot water, recovering as humidity changes (subject to "delayed" recovery/creep effects, similar to viscose rayon).
- **Effect of dilute/strong acids:** dilute mineral acids have little immediate effect but can cause hydrolysis of the peptide backbone with prolonged exposure, making the fibre brittle and yellow; concentrated acids react more quickly, degrading amino acids to soluble lower products with colour change from yellow to deep brown; organic acids act similarly but more mildly.
- **Effect of alkalis:** 5% caustic soda at the boil completely dissolves wool within minutes; dilute NaOH disintegrates the scales, with the rate of attack increasing with concentration (up to ~15%); at higher NaOH concentrations (35–40%) wool shows some immunity, attributed to the low partial vapour pressure of water over concentrated caustic solution and formation of a complex hydrate (2NaOH·7H₂O) with correspondingly low free hydroxide-ion activity; strength can even increase somewhat and lustre improve under carefully controlled strong-alkali treatment.
- **Effect of salts:** salts such as calcium/magnesium chlorides in hard water, and zinc chloride, are used with wool to impart increased fabric strength; heavy-metal salts (Fe, Cr, Cu, Sn — as sulphates, chlorides, nitrates, acetates) react strongly with wool, forming insoluble compounds — the basis of wool mordanting/dyeing.
- **Action of oxidising agents:** strong H₂O₂, KMnO₄ and K₂Cr₂O₇ damage wool via oxidation of the cystine disulphide linkages, lowering strength.
- **Halogenation:** halogens (chlorine-type treatments) attack the cuticle scales (used industrially for shrink-resist finishing of wool), increasing dye uptake but also increasing susceptibility to further oxidative damage if overdone.
- **Micro-organisms:** woollen/worsted fabrics are attacked by mildew, especially under warm, moist, alkaline conditions, weakening mechanical properties.

**Felting of wool:** The process of felting a woollen cloth to a desired finish is called **"milling."** Considerable shrinkage occurs during milling, measurable by the loss in area. Felting can be induced by **(i)** mechanical rubbing/producing the cloth with rocker-shaped fulling blocks, and **(ii)** chemical treatment at particular pH and temperature — felting is fastest at **pH below 3 and above 9**, and minimum at pH close to neutral. Felting results from **(a)** the free edges of the cuticle scales becoming entangled as fibres are drawn together under agitation (scales open at elevated temperature, ~50°C, promoting interlocking), and **(b)** migration of individual fibres, which tend to creep root-first (directional friction effect) through the felting mass. **Shrink-resist treatments:** cystine linkages can be strengthened/modified to resist felting — e.g. **resin treatments** (free amine/amide groups condensing with formaldehyde, ~2–8% concentration at pH 6–7, or with a cyclic diketone such as benzoquinone at pH 5), and **reduction–crosslinking treatments** of the disulphide bond (first reducing –S–S– to –SH with a reducing agent, then re-cross-linking with a bifunctional alkylating or metal-salt agent) to raise resistance to felting/shrinkage.

**Uses — Woollens and worsted yarns:** Wool is manufactured into two kinds of yarn — **worsted** yarns (made from longer, well-aligned, combed fibres) and **woollen** yarns (made from shorter fibres, ~under 5 cm, that are carded but not combed, giving a bulkier, less compact yarn). Worsted yarns/fabrics are smoother-faced and more compact than woollens; woollen fabrics can also incorporate reprocessed/reused wool. Wool's combination of resilience, bulk and warmth suits it to knitted goods as well as woven fabrics; both woollen and worsted fabrics are used broadly for men's and women's apparel.

---

## Topic vi) Physical, Chemical Properties and Uses of Regenerated Cellulosic Fibres — Viscose Rayon; Uses of HT Rayon

* **Chapter:** 10 – Regenerated Cellulosic Fibres
* **Page Number(s):** Book pp. 154–188 (PDF pages 164–198)
* **Extracted Content:**

### Background — Regeneration Principle
Cellulose cannot itself be melted or dissolved directly in ordinary solvents for spinning; hence a **regenerated cellulose fibre** is produced by first converting cellulose into a soluble derivative/complex (by a chemical process), dissolving/dispersing it to form a spinning solution ("dope"), extruding this through a spinnerette, and then regenerating solid cellulose in a coagulating bath. Raw cellulose sources cited include **wood** (composition roughly: Cellulose 40–50%, Lignin 20–30%, Hemicellulose 10–30%), cotton linters and other seed hairs, bast fibres (flax, hemp, ramie — containing 4–12% non-cellulosic matter, hence easier to purify), and other plant/grass wastes. Cellulose is not itself soluble in ordinary solvents such as sulphuric acid or zinc chloride solutions in a recoverable way, but it can be dissolved in certain metal-complex hydroxides — most importantly **cuprammonium hydroxide (Schweitzer's reagent)** — or converted to a soluble ester/xanthate derivative.

### Viscose Rayon — the Xanthate Process
*"Viscose rayon is a regenerated form of cellulose. In this process, purified cellulose is dissolved in NaOH to form ... cellulose xanthate ... from which cellulose is regenerated by the action of acid."* This is chemically analogous to the xanthation of alcohols; only one of cellulose's three –OH groups per anhydroglucose unit is converted to the xanthate (–O–CS–S–Na) group:

**Cell–OH + NaOH → Cell–O–Na ; Cell–O–Na + CS₂ → Cell–O–CS–S–Na (sodium cellulose xanthate)**

**Steps in the viscose process** (as listed in the text):
1. Formation of soda-cellulose (alkali cellulose)
2. Formation of cellulose xanthate
3. Preparation (ripening/filtration) of the spinning solution ("viscose")
4. Fibre formation by extrusion and regeneration in an acid coagulating bath

The overall transformation sequence given is: **(a)** swelling of cellulose chains with sodium hydroxide, **(b)** breakage of crystalline and amorphous regions, **(c)** replacement of hydroxyl groups by xanthate groups, **(d)** removal of the xanthate group and sodium during spinning/coagulation, replaced by hydroxyl groups, **(e)** formation of van der Waals forces and hydrogen bonding, **(f)** formation of the **Cellulose II** crystal structure, **(g)** purification, and **(h)** fibre formation/regeneration of cellulose.

**Manufacturing detail:** Wood pulp sheets/boards (~90–94% cellulose after sulphite/sulphate or soda-process pulping and bleaching) are steeped in about **18% NaOH** to form alkali cellulose, then pressed to remove excess liquor until the pressed material weighs about **three times** the original pulp weight. The alkali cellulose is shredded ("comminuted") into crumbs, aged for a controlled period (to reduce/adjust the degree of polymerisation via oxidative chain scission in air), then reacted with **liquid carbon disulphide** (about 30–40% of the pulp weight) in a rotating hexagonal drum (2–3 rpm) for about 3 hours, converting alkali cellulose to orange/deep-orange-brown **sodium cellulose xanthate**. The xanthate crumbs are dissolved in dilute NaOH to form the viscous spinning solution ("viscose"), which is then **ripened** (chemical maturation, reducing viscosity to the required spinning value), **filtered** to remove undissolved particles, and **de-aerated** ("desecrated"/de-aerated) under vacuum. The finished spinning solution typically contains about **6.5% cellulose, 5.5–6.5% sodium hydroxide, and 2.0–2.4% [combined sulphur/xanthate]**.

**Spinning process:** The filtered, de-aerated viscose solution is extruded through a **spinnerette** (each orifice forming one filament) immersed in a coagulating bath. **Table 10.1 — Typical Coagulating Bath Conditions:**

| Bath component | Concentration |
|---|---|
| Sulphuric acid | 8–10% (≈145 g/l) |
| Sodium sulphate | ≈ 72 g/l (as listed) |
| Zinc sulphate (ZnSO₄) | 1–2% (≈12 g/l) |
| Temperature | 45–50°C |
| Spinning speed | ≈120 m/min |

As viscose extrudes into the bath, sodium sulphate first precipitates the sodium cellulose xanthate into filament form, while sulphuric acid converts the xanthate to regenerated cellulose (Cellulose II). The nascent filaments are pulled under a bottom godet roller, then to a top godet (driven faster than the bottom one), imparting a stretch of about **100%** between the godets. For yarn collection, **centrifugal ("pot"/"box") spinning** is commonly used, forming a "cake"; collected cake is subsequently washed, purified and dried.

**Factors affecting viscose yarn quality:** (a) temperature of the coagulating bath, (b) bath composition, (c) speed of coagulation, (d) length of immersion, (e) spinning speed, and (f) stretch imparted between the godets.

**Purification of viscose fibre (four steps):** **(a) Desulphurising** (washing in dilute alkali sulphide solution around 50°C to remove residual sulphur), **(b) Washing**, **(c) Bleaching** (with hypochlorite liquor at room temperature), **(d) Washing** (to remove residual bleach).

**Regeneration chemistry summary:**

**Sodium Cellulose Xanthate → (Zn/Na sulphate) → Zinc/[intermediate] Cellulose Xanthate → (acid) → Cellulose (regenerated)**

Because zinc ions produce a "limited regeneration effect," a skin-forming ("skin-core") structure develops during coagulation: the outer skin regenerates (crystallises) rapidly on contact with the acid bath, while the still-solvent-swollen core regenerates more slowly, so viscose filaments characteristically show a **denser, more oriented skin and a more open, less oriented core**.

### Modification of Viscose Rayon (including High-Tenacity, HWM and related types)

The book explains that gel-filament plasticity and take-up stretchability can be controlled by process variants, producing a family of modified viscose fibres with enhanced properties:

- **(a) Chemical modifiers added to the viscose** (e.g. surfactant-type modifiers such as polyethylene oxide derivatives) — used for the **high-tenacity / high wet-modulus** viscose types, allowing higher stretch ratios and better fibre orientation before regeneration is complete.
- **(b) Low-acid, low-salt coagulating bath** — used for **polynosic** and other high-wet-modulus types.
- **(c) Addition of formaldehyde to the spin bath** — used for **super-high-wet-modulus** yarn (e.g. "Ten X" type).

**High-tenacity viscose rayon (from cotton linters):** conventional viscose modified via controlled zinc-sulphate concentration, low bath temperature and reduced spin-bath acid strength, with 1–3% polymeric modifiers (e.g. polyethylene oxide) added to the spin dope, allowing the gel filament to be stretched to a considerably higher draw ratio, giving higher tenacity yarn used for industrial applications such as **tyre cords, conveyor belts**, and similar high-strength textile products (this corresponds to the book's **"Tenasco"**-type high-tenacity rayon).

**High-viscosity viscose rayon — Polynosic fibres:** derived from cellulose xanthate of **very high degree of polymerisation** (i.e., the ageing/ripening step is minimised, keeping xanthate DP high). In the polynosic process, a very small amount of zinc sulphate is used, the spin-bath temperature is kept very low, and fibres are collected at low take-up speed, allowing slower coagulation/regeneration with crystallisation occurring together with orientation (Fig. 10.4–10.5, "Polynosic fibre formation process"). This produces fibre with higher crystallinity, higher wet modulus and better dimensional stability than ordinary viscose.

**Modifiers' role (as summarised in the text, Table/section on "High Wet Modulus Rayon: Super Yarn"):**
1. Modifiers assist intermediate-gel formation, resulting in slower deswelling and orientation.
2. Selective acid diffusion is a prerequisite for formation of a skin.
3. Modifiers assist formation of a "cuticle" (a particular type of surface film) during deswelling.
4. Modifiers alter colloidal contraction behaviour.
5. Modifiers reduce fibril size, increasing homogeneity of the gel structure.

**High-crimp filament yarn:** produced by extruding filaments and applying differential stretching immediately before coagulation is complete (using bath conditions of about **0.90 g/l sulphuric acid, 300 g/l sodium sulphate**, plus zinc sulphate), giving a differential cross-section with one crimped/dense half and one smoother half — this asymmetric structure imparts a durable mechanical crimp.

**"Ten X" type high wet-modulus yarn:** formaldehyde is added to the spin bath to increase plasticity of the as-spun gel filament. Distinguishing process conditions: **(a)** zinc sulphate percentage kept higher than usual; **(b)** spin-bath temperature kept very low; **(c)** low spinning speed (~40–50 m/min); **(d)** ~1% formaldehyde added in the spin bath (or a related stage). As-spun filaments made this way can be stretched **6× to 7×**, achieving very high orientation and wet modulus.

**Table 10.4 — Degree of stretching applied to different viscose fibre types (reconstructed):**

| Fibre type | Stretch ratio |
|---|---|
| Ordinary (regular) rayon | ≈1.5× – 2.0× |
| High-tenacity ("Tenasco"-type) | ≈1.75× – 2.25× |
| High-wet-modulus (polynosic) | ≈2.25× – 2.9× |
| "Ten X" type / super HWM | up to ≈6–7× |

**Table 10.5 — Tensile properties of different viscose rayon types (reconstructed, partial data legible):**

| Property | Regular rayon | High-tenacity | Polynosic | High-wet-modulus |
|---|---|---|---|---|
| Tenacity, conditioned (g/den) | ≈2.5 | ≈4.1–4.5 | ≈4.0 | [higher] |
| Tenacity, wet (g/den) | lower | higher retention | higher retention | highest retention |
| Elongation, conditioned (%) | ≈15–18 | lower | lower | lowest |
| Elongation, wet (%) | higher than dry | — | — | — |

*(The exact numeric grid in Table 10.5 was only partially legible in the scan; the qualitative trend — tenacity and wet-strength retention increasing from regular → high-tenacity → polynosic → super/HWM types, with elongation decreasing in the same order — is clear from the surrounding text and is reproduced faithfully; please refer to PDF p. 186 for the exact figures.)*

### General Physical Properties of Viscose Rayon
- **Moisture regain:** approximately **5% at ~15% RH, 7.5% at ~30% RH, 10.5% at ~65% RH, and 22% at ~90% RH** (rises steeply at high humidity — viscose is highly absorbent).
- **Swelling:** axial swelling of about **0.4–0.7% for normal viscose rayon and 0.7–2.0% for highly [oriented/modified] rayon** occurs on wetting; the presence of water in the regenerated cellulose structure alters strength and other mechanical characteristics.
- **Delustring/oils:** viscose absorbs oils and delustring pigments tenaciously; removal is not always easy due to uneven absorption.
- **Elastic behaviour:** viscose rayon has relatively low elasticity; on stretching and release it does not immediately return to original length but continues to shrink slowly toward (but not fully back to) the original length afterward — a phenomenon the book calls **"delayed elasticity," "creep,"** or **"plasticity."** This can cause permanent stretch and streaky dyeing if yarn ends are subjected to sudden strain during weaving.
- **Density:** **1.52 g/cc** — *"same as that of cotton."*
- **Electrical properties:** because of high moisture absorption, viscose is a poor electrical insulator when damp, though it is a good insulator when perfectly dry; it is less prone to static buildup in textile processing than cellulose acetate.

### Chemical Properties of Viscose Rayon
- **Degradation mechanisms:** acids cause **hydrolytic degradation** (chain scission via hydrocellulose formation), while oxidising agents attack via oxidative chain cleavage, forming **oxycellulose**; both are destructive processes. Light exposure, via partial oxidation, forms **photocellulose**.
- **Effect of light:** regenerated cellulosic fibres deteriorate under light, particularly from UV; damage is described as somewhat greater at moderate humidity (~45% RH) than at higher humidity (~65% RH) in the source. Viscose loses relatively little strength on UV exposure compared to some other fibres but does lose some flexibility, associated with photocellulose formation.
- **Action of dry heat:** as with light, heat causes progressive strength loss (rate depends on temperature and moisture content present); degradation is slower in the absence of oxygen; short exposure at high temperature (e.g. 140°C) is generally less damaging than prolonged exposure at lower temperature. Viscose rayon's dry heat resistance is described as somewhat less than that of cotton.
- **Action of oxidising bleach agents:** sodium hypochlorite (NaOCl) in acid solution has a more destructive bleaching action than in alkaline solution; hence it should be applied cold and dilute; alkaline hypochlorite bleaching is milder. Potassium permanganate bleaching must be followed by careful acid after-treatment (to avoid MnO₂ deposition, which itself can catalyse further oxidative damage); hydrosulphite-based reducing bleach systems (e.g. sodium hydrosulphite, sulphoxylate-formaldehyde types) can form small amounts of hydrocellulose if over-treated.
- **Action of solvents:** common organic solvents (pine oil, hydrocarbons, toluene, xylene, petrol, carbon tetrachloride) do not seriously damage regenerated cellulosic fibres and are used industrially as spotting agents or scouring-bath additives.
- **Sensitivity to iron:** ferrous/ferric hydroxide deposits (from rusty equipment, water, or iron-contaminated processing) can catalyse oxidative degradation of cellulose to oxycellulose in the presence of air/moisture; contact with iron or iron salts should therefore be avoided during scouring, bleaching, dyeing and throwing.
- **Dyeing properties:** viscose dyes readily with the same classes of dyestuff used for cotton; dyeing is best carried out at relatively low temperature, with retarding agents and lower electrolyte concentration used to control uniformity across filaments.
- **Biological properties:** as with other cellulosics, viscose rayon is susceptible to microbial (fungal/bacterial) attack under warm, moist conditions.

### Uses of High-Tenacity (HT) Rayon *(Topic-specific focus)*
Per the modification section above, **high-tenacity viscose rayon (industrial rayon / "Tenasco"-type)** is specifically engineered — via modifier addition, controlled bath chemistry and higher stretch ratios — to achieve substantially higher dry and wet tenacity and better dimensional (wet-modulus) stability than regular textile-grade viscose. The text identifies its principal application area as **industrial textiles**: it states such **"high tenacity viscose yarns are produced for industrial [end uses]. They are used for manufacturing tyre cords, conveyor belts and other [reinforcement/technical] [products]."** By extension of the surrounding discussion of polynosic and super/HWM (high-wet-modulus) grades, related high-tenacity/HWM viscose types are also used for apparel fabrics requiring good wet dimensional stability (reduced shrinkage/growth when wet) and for durable-press-type finishing applications, owing to their improved wet strength and reduced "delayed elasticity"/creep relative to ordinary viscose rayon.

---

## Topic vii) Physical, Chemical Properties and Uses of Synthetic Fibres — Polyester, Nylon 6,6 and Acrylic

### (A) POLYESTER — Poly(ethylene terephthalate), PET

* **Chapter:** 13 – Polyester Fibres
* **Page Number(s):** Book pp. 227–243 (PDF pages 237–253)
* **Extracted Content:**

**Historical background:** The chapter credits **W.H. Carothers'** pioneering work on linear condensation polymers (including early polyester experiments from dibasic acids and glycols) as the foundation, but notes his materials had melting points too low (and were too easily hydrolysed) for good fibre use. The breakthrough came from **J.R. Whinfield** [and J.T. Dickson, in England], who obtained a high-molecular-weight, high-melting polymer using **terephthalic acid** instead of aliphatic diacids — **poly(ethylene terephthalate), "PET."**

**Chemistry:** Polyester fibre is defined as *"a manufactured fibre in which the fibre-forming substance is a long-chain synthetic polymer composed of at least 85% by weight of an ester of a dihydric alcohol and terephthalic acid."* Fig. 13.1 shows the polymer's repeat unit: **–[O–CH₂–CH₂–O–CO–C₆H₄–CO]–ₙ**.

**Synthesis of the monomer:**
- **Ethylene glycol manufacture:** produced from **ethylene oxide** (itself from ethylene, via chlorohydrin or catalytic oxidation with a silver catalyst — the oxidation route now dominant over the older chlorohydrin process). Ethylene oxide is hydrated to ethylene glycol: **CH₂=CH₂ + H₂O → HO–CH₂–CH₂–OH** (catalysed by dilute sulphuric acid at 60–70°C, followed by removal of the acid as insoluble calcium salts).
- **Terephthalic acid manufacture:** from **p-xylene**, oxidised via a **one-step method** (catalytic air oxidation with cobalt naphthenate catalyst at 150–180°C, 4–10 atm, ~92% yield) or a **two-step method** (first oxidation to p-toluic acid at 125–140°C with Co/Cr/Ni naphthenate catalyst, ~80% toluic acid + 5% terephthalic acid, followed by a second oxidation stage at ~195°C with ~60% nitric acid to complete conversion to terephthalic acid). An alternative multi-stage oxidation of p-xylene yields **dimethyl terephthalate (DMT)** via methyl-p-toluate and the monomethyl ester of terephthalic acid.
- **Dimethyl terephthalate (Table 13.3, properties):** Melting point **141°C**; Acid number and Saponification number values given; Ester interchange value **≈96% in 2 hrs.**

**Polymerisation process — two industrial routes:**
1. **Route 1 — from purified terephthalic acid (PTA):** direct esterification of PTA with excess ethylene glycol, followed by polycondensation; advantages cited include better thermal stability/colour and better drawability of the resulting fibre, using a chemically pure, monomeric starting material; the reaction is conducted at about **260–280°C** as excess glycol is distilled off.
2. **Route 2 — from dimethyl terephthalate (DMT):** DMT + ethylene glycol undergo **transesterification** (ester interchange) with loss of methanol, using catalysts such as acetates of Co, Zn, Mn, Cd (sometimes combined with oxides of Pb, Sb, Mg) at temperatures around 130–200°C; the resulting bis(hydroxyethyl) terephthalate monomer is then polycondensed under vacuum at high temperature (~280°C) with continued removal of excess glycol.

The complete process (as flow-charted in the text) comprises: **(i)** transesterification/esterification, **(ii)** [intermediate steps], **(iii)** polycondensation under vacuum, **(iv)** melting of the [pre-]polymer, **(v)** extrusion of the glycol/monomer, **(vi)** [chip formation], and **(vii)** mixing and finishing — with reaction vessel, catalyst, reaction temperature and vacuum level all identified as critical to achieving high-grade (high-viscosity) polymer.

**Spinning process — melt spinning:** Polyester is spun by **melt spinning**, comprising: **(a)** manufacture of the spinning melt, **(b)** spinning of the polyester melt, **(c)** preparation and winding of the spun (undrawn) filament, and **(d)** drawing of the filament. Polymer chips are dried (moisture content is critical, since residual water hydrolyses the ester linkages during melting) in dryers at around **160–180°C**, then melted (melt temperature typically ~280–290°C) and metered through a **gear/metering pump** to the spinnerette. Filaments are cooled/solidified in a quench zone, given a spin finish (moisture/lubricant, applied via kiss-roll or spray systems), and wound up; high-speed spinning gives a partially oriented ("as-spun") filament suitable either for direct texturing or for subsequent drawing. Drawing of PET is generally carried out at elevated temperature, typically in the range **80–187°C** (values as legible), producing the final oriented, higher-tenacity filament (**"continuous process for fibre formation,"** integrating spinning and drawing, is also described).

**Structure of PET:** The polymer chain contains rigid benzene rings linked by flexible ethylene (–CH₂–CH₂–) groups via ester linkages; the benzene ring restricts chain mobility, giving PET a relatively high **melting point (~250–265°C)** and a **glass-transition temperature around 70–80°C** (values as legible: ~78–80°C is cited). PET crystallises with a **triclinic unit cell** (a ≈ 4.56 Å, b ≈ 5.94 Å, c (fibre repeat) ≈ 10.75 Å, α ≈ 98.5°, β ≈ 118°, γ ≈ 112°); neighbouring chains are held together mainly by **van der Waals forces** (no unusual special bonding). As-spun filament is largely amorphous with low orientation; cold drawing converts this to an **oriented amorphous** structure, and subsequent heat-setting/annealing develops crystallinity; at higher draw ratios, straight-chain-type crystallites form, with amorphous regions separating adjacent crystallites (a classic semi-crystalline fringed-fibril morphology).

**Physical properties (Table 13.4, approximate ranges):**

| Property | Value |
|---|---|
| Tenacity (g/den), dry | 3 – 10 |
| Tenacity (g/den), wet | ≈ same as dry (little loss) |
| Breaking elongation (%) | 12 – 30 (up to ~50 for some types) |
| Elastic recovery (%) at 2% strain | 90 – 96 |
| Elastic recovery (%) at 10% strain | 55 – 60 |
| Initial modulus | high (20–70 range as tabulated) |
| Moisture regain (%) at 65% RH | ≈0.4 |
| Moisture regain (%) at 95% RH | ≈0.6 |

**Thermal properties:** the fibre softens around **225–230°C** and melts at **255–265°C**; continuous exposure near 150°C causes gradual strength loss over time; at higher temperatures, random chain scission occurs at the ester linkages, with degradation preferentially initiating at the methylene groups (schematically: **–O–(CH₂)₂–O– → O=CH₂ (formaldehyde-type fragment) + ...**, releasing volatile fragments) — this degradation is most significant in the final stages of polycondensation and during melt spinning if temperatures are not controlled.

**Chemical properties:**
- **Effect of acids:** PET shows good resistance to inorganic (mineral) acids at room/moderate temperature; hot concentrated acids cause more significant hydrolytic attack over time.
- **Effect of alkalis:** PET is fairly resistant to weak alkalis at room temperature but shows only moderate resistance to strong alkalis, especially at elevated temperature and prolonged contact time — hot caustic soda progressively attacks/hydrolyses the fibre surface (the basis of alkaline "weight-reduction" finishing of polyester fabrics).
- **Resistance to mildew/moths:** PET is not weakened by mildew or insect attack.
- **Effect of sunlight:** behind glass, PET shows good light resistance; on direct/prolonged exposure to sunlight it can degrade via free-radical formation and chain cleavage, causing gradual strength loss.
- **Dyeing:** because of its hydrophobicity and compact crystal structure, PET requires special high-temperature or carrier-assisted dyeing methods; **disperse dyes** are the dye class mostly used for polyester.

**Applications:** Polyester fibre is extensively used as **filament or staple fibre**, alone or blended with cellulosic fibres, for apparel of all types; also widely used in **home furnishings, sewing thread, ropes, tyre cords**, and various other industrial applications.

**Related polyester types (briefly noted in the same chapter):**
- **Poly(butylene terephthalate), PBT:** made similarly to PET but using **1,4-butanediol** instead of ethylene glycol; the two additional methylene groups increase chain flexibility, giving a **lower glass-transition temperature (~40°C region)** and a **lower melting point than PET** (cited around 200–225°C — exact figure only partly legible), and improved dyeability without carriers.
- **Kodel fibre (a poly(1,4-cyclohexylene-dimethylene terephthalate)-type polyester):** noted as another polyester variant with distinct physical characteristics (higher melting point around 290–295°C, lower density, soluble in solvents such as methylene chloride under specific conditions) and used similarly as a fibre-fill and staple-fibre material.

---

### (B) NYLON 6,6 [Poly(hexamethylene adipamide)]

* **Chapter:** 12 – Polyamide Fibres
* **Page Number(s):** Book pp. ~207–218 (PDF pages 220–229)
* **Extracted Content:**

**Raw materials / monomer preparation:** Nylon 6,6 is formed by condensation of two monomers — **adipic acid (ADA)** and **hexamethylene diamine (HMD)**:

**n HOOC–(CH₂)₄–COOH + n H₂N–(CH₂)₆–NH₂ → [–OC–(CH₂)₄–CO–NH–(CH₂)₆–NH–]ₙ + 2n H₂O**

("6,6" refers to each monomer contributing six carbon atoms.)

**Manufacture of adipic acid:** several routes are described, including oxidation via **cyclohexanol/cyclohexanone** (from cyclohexane, air-oxidised with Co catalyst at 120–150°C, reaction interrupted at ~10–15% conversion, giving a mixture of cyclohexanol and cyclohexanone that is further oxidised — with nitric acid, e.g. ~50% nitric acid at ~60°C, or via a manganese-catalysed route with dilute nitric acid) to yield adipic acid; unconverted cyclohexane is recycled.

**Manufacture of adiponitrile** (intermediate toward hexamethylene diamine): described via **(1)** vapour-phase ammonia + adipic-acid condensation (vaporised adipic acid reacted with excess ammonia; endothermic, ~57 cal/mole; yield ~88%), and **(2) electrohydrodimerisation of acrylonitrile** (electrolytic reductive coupling of two acrylonitrile molecules: **2 CH₂=CH–CN + 2e⁻ + 2H⁺ → NC–(CH₂)₄–CN**), conducted under controlled current density and pH (optimum around pH ≈ 2.5–[somewhat higher]).

**Manufacture of hexamethylene diamine:** by hydrogenation of adiponitrile; the product is described as a solid melting near 40–42°C (readily soluble in water and alcohol).

**Polymerisation (four main steps, Fig. 12.5):** **(1) Salt preparation** — hexamethylene diamine (as a 60–70% aqueous solution) and adipic acid are combined in exactly stoichiometric (1:1 amine:acid) proportions to form **"AH salt"** (nylon salt), since exact stoichiometry is essential for achieving high molecular weight (any excess monomer terminates chains via unreacted end-groups); the AH salt is a white crystalline solid (melting point ≈190°C), typically stored/handled as a ~60% solution in water; methanol may be used in the salt-forming step and is recovered by centrifugation/washing. **(2) Polycondensation** — the concentrated salt solution (~60% in water, with ~0.5% acetic acid added as a chain-length stabiliser/viscosity control agent) is fed to an autoclave; the reaction is heated to about **275°C** under increased pressure (held at about **1.8 MPa**), after purging with pure nitrogen (<0.005% O₂) to prevent oxidative degradation/discolouration; as water of condensation distils off, pressure is allowed to fall to atmospheric, and the batch is held at about **270°C** at atmospheric pressure for further reaction. **(3) Melting/extrusion** — the molten polymer is extruded from the autoclave as a ribbon and quenched/solidified (e.g., on a cooled casting wheel), then chipped and dried. **(4) Fibre spinning** — carried out by **melt spinning**, in a manner analogous to Nylon 6 (see Chapter 2 for general melt-spinning method): the molten polymer is filtered and pumped through the spinnerette, and the extruded filaments are drawn to develop orientation and the required tenacity/elongation profile.

**Process variables affecting fibre properties** (as listed): **(a)** [extrusion temperature], **(b)** winding speed, **(c)** spin-draw ratio, **(d)** draw ratio, and **(e)** [heat-setting/annealing conditions] — these determine the resulting tensile strength, modulus, crystallinity and molecular orientation.

**Physical properties (Table 12.6, approximate ranges across staple/filament/high-tenacity Nylon 66 types):**

| Property | Regular/Staple fibre | Regular filament | High-tenacity filament |
|---|---|---|---|
| Density (g/cc) | ≈1.13 | ≈1.14 | ≈1.15 |
| Moisture (%) at 65% RH | ≈4.0–4.5 | ≈4.0–4.5 | ≈4.0–4.5 |
| Moisture (%) at 100% RH | ≈6.9–8.0 | ≈6.0–8.0 | ≈6.0–8.0 |
| Tenacity, dry (g/den) | ≈3.0–6.8 | ≈2.3–6.0 | ≈6.0–10.0 |
| Tenacity, wet (g/den) | ≈2.5–6.1 | ≈2.0–5.5 | ≈5.1–8.0 |
| Elongation at break (%) | ≈16–75 | ≈25–65 | ≈15–28 |

*(Nylon 66's differences from Nylon 6 — melting point, tenacity retention and draw-ratio behaviour — are discussed comparatively in the surrounding text via a "Normal vs. High-tenacity Nylon" comparison table, but the exact figures for that particular comparison table were only partly legible in this scan; the Nylon 66-specific Table 12.6 above is fully reconstructed from the clearly legible portions.)*

**Chemical properties:** Nylon 66 is attacked by **strong acids** (e.g., concentrated sulphuric, hydrochloric, formic and nitric acid); the fibre is more resistant to weak acids under mild conditions. It is attacked by **strong alkalis** but essentially inert to weak/dilute alkalis. It is largely **insoluble in common organic solvents**, dissolving mainly in a few specific solvents (e.g., formic acid, phenolic solvents, certain concentrated acids). Nylon 66 has **excellent resistance to biological attack** (mildew/insects). Dyeing occurs with a range of dye classes, with dye uptake affected by fibre crystallinity/orientation.

**Additional physical/mechanical characteristics (as listed in the text — general Nylon properties, applicable to Nylon 66):** high strength and modulus; good toughness and impact resistance; low friction ("self-lubricating" surface); good wear/abrasion resistance; relatively low density; high specific electrical resistance; a glass-transition (second-order) temperature region noted in the text; good resilience.

**Applications:** (from the general polyamide-fibre "Applications" section of the chapter, book p. 218) Nylon 66 is used broadly in **apparel** (hosiery, lingerie, outerwear), **carpets and upholstery**, and **industrial/technical applications** (tyre cord, ropes, parachutes, industrial webbing) — leveraging its high strength, elasticity, abrasion resistance and relatively low density.

---

### (C) ACRYLIC — Polyacrylonitrile (PAN) Fibre

* **Chapter:** 15 – Vinyl Fibres
* **Page Number(s):** Book pp. 262–276 (PDF pages 272–286)
* **Extracted Content:**

**Overview (Table 15.1, "Important Vinyl Fibres" — extract):**

| Polymer | Generic/Trade name(s) |
|---|---|
| Poly(acrylonitrile) | Acrylic |
| Copolymers of polyacrylonitrile | Modacrylic |
| Poly(vinyl alcohol) | Kuralon, Vinal |
| Poly(vinyl chloride) | Vinyon, Rhovyl |
| Copolymers of poly(vinyl chloride) | Dynel, Cordelan |
| Poly(vinylidene chloride) | Saran, Velon |
| Poly(tetrafluoroethylene) | Teflon |

**Introduction:** *"Poly(acrylonitrile) or PAN fibre is one of the important fibres because of their warm feeling, bulky hand, good resiliency, higher wrinkle resistance and favourable aesthetic properties."* **Acrylonitrile** is the raw material for PAN fibre; a "100% acrylic" fibre must be composed of at least 85% acrylonitrile units by weight (other comonomers limited to a maximum of about 15%, per standard definition, echoed in the text's later "Modification of the polymer" discussion).

**Preparation of acrylonitrile — three commercial routes:**
1. **From ethylene** — via ethylene cyanohydrin (ethylene oxide + HCN, followed by dehydration).
2. **From acetylene + HCN** — passing the mixture over a catalyst.
3. **From propylene (ammoxidation route)** — the now-dominant industrial route: **CH₂=CH–CH₃ + NH₃ + 1.5 O₂ → CH₂=CH–CN + 3 H₂O**, using a bismuth-molybdenum-type catalyst at about **400–500°C** and **1–3 atmospheres**. Advantages cited for this route: **(1)** low raw-material cost, and **(2)** avoidance of poisonous hydrogen cyanide as a required reagent — this route "is becoming dominant."
4. **From acetaldehyde + HCN**: **CH₃CHO + HCN → CH₃–CH(OH)–CN → (dehydration) → CH₂=CH–CN + H₂O** (a further, older route, mentioned for completeness).

**Polymerisation:** Poly(acrylonitrile) is typically produced by **free-radical addition polymerisation**, via initiation, propagation and termination steps; industrially, several polymerisation techniques are used, described with advantages/disadvantages:
- **Bulk polymerisation** — PAN is insoluble in its own monomer, so precipitation of polymer occurs as it forms; conducted around **30–60°C at ~5 atmospheres for about one hour**; disadvantages: strongly exothermic reaction (heat removal is difficult), and formation of a thick paste making product removal/handling difficult; not directly usable for spinning without further processing.
- **Suspension polymerisation** — advantages: better heat removal, polymer formed in a granular/bead form; disadvantages: requires violent stirring, and the process needs further steps before spinning.
- **Emulsion polymerisation** — the monomer is dispersed in water with water-soluble catalysts (e.g. hydrogen peroxide, or redox/persulfate-type initiators); polymerisation rate is initially proportional to monomer concentration; typically conducted around **50°C**; advantage: better heat removal; disadvantage: the resulting latex/solution is not directly usable for spinning (as with bulk).
- **Solution polymerisation** — the industrially favoured route for fibre production: monomer is polymerised directly in a solvent (e.g., using **AIBN, azobisisobutyronitrile**, as initiator), at a reaction temperature around 50–60°C; the resulting polymer solution is essentially independent of further isolation/dissolution steps, giving **(1)** lower investment, and **(2)** minimum additional processing — *"This process is generally followed in [the] fibre industry."*

**Fibre spinning:** Three principal methods are named — **melt spinning, dry spinning, and wet spinning**.
- **Melt spinning:** PAN decomposes near/below its notional melting point, so true melt spinning is not industrially practical unless small amounts of plasticiser (e.g. dimethylformamide-related additives, tetramethylene sulfone, ethylene carbonate) are blended in and extrusion carried out around **140–180°C**; the text notes that "a stable [molten] phase of ... polyacrylonitrile is difficult to obtain, so melt spinning has not been applied industrially" — dry and wet spinning are the fibre-forming processes actually used.
- **Solvent (dry/wet) spinning — solvent choice (Table 15.2):** major solvents used include **dimethylformamide (DMF), dimethylacetamide (DMAc), dimethyl sulphoxide (DMSO), concentrated nitric acid, sodium thiocyanate (NaSCN) solution, and zinc chloride solution**.
- **Dry spinning:** typically using **DMF** at 20–30% polymer concentration; the filtered dope is extruded through a spinnerette (300–600 holes) into a heated column (air circulating at about **230–260°C**; DMF boils at ~153°C), evaporating the solvent and solidifying the filaments, which are then collected on take-up rollers. Advantages: higher achievable spinning speeds than wet spinning; a greater percentage of solvent can be recovered; the resulting filament is generally denser (less porous) than a wet-spun filament. Disadvantages: turbulence effects in the hot-air column can be a control issue; process control of solvent removal is more demanding.
- **Wet spinning:** the dope (in DMF, DMAc, DMSO, or other solvent per Table 15.3) is extruded into a **coagulation bath** containing a non-solvent/dilute solvent mixture that extracts the spinning solvent from the nascent filament without dissolving the polymer itself. **Table 15.3 — representative wet-spinning conditions (reconstructed):**

| Solvent | Solvent conc. (dope) | Polymer conc. | Coagulation bath chemical | Bath conc. | Bath temp. |
|---|---|---|---|---|---|
| Dimethylformamide (DMF) | ~100 | ~17–25% | DMF (dilute) | ~40–50% | [low] |
| Dimethylacetamide (DMAc) | ~100 | ~17–25% | DMAc (dilute) | ~40–65% | [moderate] |
| Dimethyl sulphoxide (DMSO) | ~100 | ~20% | DMSO (dilute) | — | — |
| Aq. nitric acid | ~12–16% | — | Nitric acid | ~[dilute, cold] | cold |
| Sodium thiocyanate | ~45–55% | ~10–15% | NaSCN | ~10–15% | — |
| Zinc chloride | — | ~8–12% | ZnCl₂ | — | — |
| Sulphuric acid | ~70–75% | ~10% | H₂SO₄ | ~50–55% | — |

*(This grid was reconstructed from the clearly legible cells of the original scanned table; a few individual numeric values were not fully legible and are shown as ranges/approximations — refer to PDF p. 281 for exact figures.)*

**Stretching:** After coagulation the gel filament (still containing ~10% residual solvent) is washed, then stretched (drawn), typically at **70–100°C** with steam or hot water, using a stretch ratio in roughly the range noted in the text (up to about 10×, per the surrounding discussion), to develop orientation and tenacity; after stretching, yarns are further processed (washing, drying, crimping, cutting).

**Structure of acrylic fibre:** PAN's nitrile (–C≡N) side groups are strongly polar, and the polymer backbone is understood to adopt a somewhat **helical conformation** due to steric/dipolar interactions between adjacent nitrile groups (a form of "atactic-with-helical-character" packing rather than a simple extended zig-zag). Chains pack with significant **lateral (equatorial) order** but comparatively little **longitudinal order** along the fibre axis, so PAN fibre shows only **moderate crystallinity** overall; infra-red spectroscopy indicates PAN is "neither fully amorphous nor fully crystalline" — often described as **paracrystalline**. The fibre also shows a characteristic microvoid/porosity structure related to its spinning process.

**Modification of the polymer:** 100%-PAN homopolymer fibre has practical difficulties: **(a)** poor dyeability, **(b)** limited thermoplasticity, and **(c)** difficulty in stretching/crimping. To address these, comonomers are copolymerised with acrylonitrile:
- **Non-ionic comonomers** (e.g. methyl acrylate, methyl methacrylate, vinyl acetate) — improve dye-site diffusion and reduce crystallinity/increase flexibility, aiding dyeability and processability.
- **Ionic comonomers** — introduce charged dye-sites to improve dyeability with specific dye classes: e.g., **acrylic acid or its sodium salt, itaconic acid or its sodium salt, sodium/potassium styrene sulphonate, sodium allyl sulphonate, sodium methallyl sulphonate**, and amine-containing comonomers (e.g. vinylpyridine, ethyleneamine types) for improved hydrophilicity/antistatic character and specific dye affinity (acid-dyeable vs. basic/cationic-dyeable variants).

**Modacrylic fibres:** fibres containing a substantially higher proportion of comonomer than "acrylic" (per the standard convention, roughly 35–85% acrylonitrile) — offering enhanced flame resistance and different dyeing/handling characteristics compared with regular acrylic.

**Physical properties (Table 15.5, Acrylic vs. Modacrylic — reconstructed):**

| Property | Acrylic | Modacrylic |
|---|---|---|
| Tenacity, dry (g/den) | 2.5 – 4.5 | 1.5 – 3.0 |
| Tenacity, wet (g/den) | [lower than dry] | [lower than dry] |
| Elongation at break (%) | ≈20–48 | ≈[similar range] |
| Moisture regain (%) | ≈1.0–2.5 | ≈0.5 – 4.0 |
| Density (g/cc) | 1.14 – 1.19 [range as legible ~1.30–1.37 for some data rows] | ≈1.30–1.37 |
| Softening temperature (°C) | 150 – 160 | 135 – 160 |
| Melting temperature (°C) | 330 – 340 (with decomposition preceding melting) | 200 – 210 |

*(As with earlier tables, the scan of this particular table was partly degraded; ranges above are reproduced as legible, and the general Acrylic-vs-Modacrylic pattern — Modacrylic melting/softening at distinctly lower temperature, reflecting its higher halogenated-comonomer / flame-retardant content — is clearly stated in the surrounding text.)*

**Chemical properties:** Both acrylic and modacrylic fibres show **excellent resistance to** chemical agents generally, oxidising agents, reducing agents, biological agents (mildew/insects), and light. They are attacked only by **concentrated acids**, and are soluble in certain **ketones (e.g. acetone)** and other strong polar solvents (the spinning solvents themselves, e.g. DMF/DMSO). Both are good electrical insulators but tend to build up **static charge**. Dyeing is with **basic (cationic), disperse and/or acid dyes**, depending on the specific comonomer/dye-site chemistry.

**Applications:** Owing to their **bulky, wool-like hand, moderate strength, good abrasion resistance, resistance to piling and wrinkling, and good resistance to sunlight/weathering**, acrylic fibres are used in fabrics such as **shawls, sweaters, blankets and knitted apparel**; modacrylic fibres (with their lower melting point and inherent flame resistance) are used in applications such as **wigs/hair goods, rugs, and flame-resistant fabrics**.

---

## Topic viii) Requirements of Fibre-Forming Polymers; Spinning of Polymers — Melt Spinning, Wet Spinning, Dry Spinning

### (A) Requirements of Fibre-Forming Polymers

* **Chapter:** 2 – Fibre Formation ("Characteristics of Fibre-Forming Polymers")
* **Page Number(s):** Book p. 21 (PDF page 35)
* **Extracted Content:**

*"Both natural and man-made fibres are mainly composed of ... high polymers or macromolecules. Macromolecular [materials are the source] of materials of high mechanical strength ... [because in fibres] the chain molecules are oriented into parallel bundles in the process of growth."* Based on this, the book states that **a polymer must satisfy certain minimum requirements if it is to serve as a fibre**:

1. **Linearity:** *"The polymer must be a linear, flexible macromolecule with a high degree of symmetry."* The effective cross-sectional diameter of the chain should be **less than about 15 Å**, and the polymer should not carry bulky side groups/branches that would disrupt close chain packing.
2. **Molecular mass:** the polymer must have a **comparatively high molecular mass**; the length of the molecular chain should be of the order of **1000 Å or more**.
3. **Configuration:** the molecule must be able to adopt an **extended chain configuration**, and possess **a high degree of intermolecular cohesion** — i.e., the molecular chains must pack closely enough, and present enough sites of attraction (hydrogen bonding, dipole, van der Waals, or covalent cross-links), for the assembly of chains to hold together as a coherent, strong fibre.
4. *(A further requirement — orientability/crystallisability of the assembled chains during fibre formation and drawing — is implied by the surrounding discussion of chain orientation "into parallel bundles," continuing into the following page on polymerisation techniques.)*

These requirements explain why only linear (or controlled, lightly-branched) polymers of sufficiently high molecular weight — such as cellulose, the polyamides, polyesters, and polyacrylonitrile — are useful fibre-forming polymers, whereas highly branched or cross-linked (network) polymers, or very low-molecular-weight materials, cannot be melt- or solution-spun into usable textile fibres.

*(Related context, same chapter, on monomer functionality:* a monomer must have a **functionality of at least 2** (two or more reactive groups, or the ability to add across two other molecules) to build a polymer chain at all; **mono-functional** systems terminate immediately and cannot polymerise; **bi-functional** systems give linear polymers (fibre-forming); **poly-functional (tri-functional or higher)** systems can give **branched or cross-linked** polymers, which — per the "linearity" requirement above — are generally unsuitable as fibre-forming polymers because they are insoluble/infusible and cannot be drawn into oriented filaments.)*

---

### (B) Spinning of Polymers — Melt, Dry and Wet Spinning

* **Chapter:** 2 – Fibre Formation
* **Page Number(s):** Book pp. 22–33 (PDF pages 36–44)
* **Extracted Content:**

*"The main methods used for fibre formation, i.e., spinning, are decided by the physical and chemical properties of the polymer. Owing to this, spinning can be of two types, i.e., melt spinning and solution spinning. However, due to differences in the solidification process, solution spinning is [further divided into dry spinning and wet spinning]. So, in general, spinning can be [of three types]: (1) melt spinning, (2) dry spinning, and (3) wet spinning."*

#### 1. Melt Spinning
**Requirement:** *"The melt spinning process can be applied ... when the polymer on melting will give a viscous liquid without decomposition. So an important requirement of the polymer to be melt spun is that it must have a [definite] melting point and should not degrade when softened by heat."* A polymer that degrades at its melting/extrusion temperature is unsuitable for melt spinning.

**Process (Fig. 2.1):** the molten polymer is extruded through a spinnerette at a **constant rate**, under a pressure of about **70–150 [atmospheres, or the stated pressure unit]**, and the extruded filaments solidify on cooling in air. Because of the high processing temperature, considerable engineering precision is required. The industrial fibre-production sequence comprises:
- **(a)** Feeding of the polymer (as chips or melt) to a hopper.
- **(b)** Melting of the chips (if not already molten).
- **(c)** Homogenisation of the melt.
- **(d)** Filtration of the molten polymer.
- **(e)** Uniform metering/feeding of the molten polymer and further filtration in the spin block.
- **(f)** Extrusion of the molten polymer into filaments (through the spinnerette).
- **(g)** Solidification of the extruded filaments in a cooling ("quench") chimney.
- **(h)** Collection of the filaments into a package.
- **(i)** Post-spinning operations (drawing etc.).

Melt spinning is the **preferred method** where applicable because: it avoids the need for a solvent (and hence solvent-recovery costs/complexity); it is generally the fastest and most economical spinning method; and it gives good control of filament cross-section (since the extruded melt is not diluted by solvent).

**Limitation:** *"only limited polymers ... [can be converted] into fibres by [the] melt spinning process."* For polymers such as **cellulose and PVC**, which do not give a stable, non-decomposing melt, this method cannot be used, and such polymers must instead be converted into fibres by **solution spinning**.

**Table (Chapter 2) — Representative fibres formed by Melt / Dry / Wet spinning:**

| Method | Example fibres |
|---|---|
| **Melt spinning** | Nylon (polyamides), Polyester, Polyethylene, Polypropylene |
| **Dry spinning** | Cellulose acetate (acetylated cellulose), Vinyon (vinyl chloride/vinyl acetate copolymer), Orlon (poly(acrylonitrile)) |
| **Wet spinning** | Viscose (cellulose), Casein, Vinylon (poly(vinyl alcohol)), PVC (poly(vinyl chloride)) |

#### 2. Dry Spinning
**Principle:** similar in overall layout to melt spinning, but the spinnerette is fed with a polymer **solution ("dope")** rather than a melt (Fig. 2.2). The process comprises: **(1)** formation of the dope by mixing the polymer and solvent; **(2)** metering of the dope through a filter into the spin block; **(3)** extrusion through the spinnerette into a heated chamber ("solvent [evaporation] chamber") through which heated inert gas or air is circulated; **(4)** solvent evaporation and filament solidification within this chamber; **(5)** take-up of the solid filament.

**Solvent choice requirements:** the solvent must be **completely and easily removable in the presence of heat**, and should have properties such as **low boiling point, low latent heat of evaporation, good heat stability, and chemical inertness**.

**Solidification mechanism (Fig. 2.3):** solidification in dry spinning involves a combination of **inward heat transfer** (heating the filament, "H") and **outward mass transfer** of solvent ("S"), occurring in two stages: **(1)** diffusion of solvent from the centre of the filament to its surface, and **(2)** evaporation of solvent vapour from the surface into the surrounding atmosphere. Because the **evaporation rate at the surface is generally faster than the diffusion rate from the core**, the filament surface tends to skin over and shrink irregularly, so that **a circular spinnerette hole often produces a non-circular (irregular/dog-bone) fibre cross-section**.

Additional solidification-controlling factors listed: **(a)** the state of the polymer, **(b)** vapour pressure of the solvent, **(c)** heat-transfer coefficient, and **(d)** gas-circulation rate in the spinning chamber. The polymer–solvent system should be chosen such that the solution undergoes **controlled phase separation**, into a concentrated polymer-rich gel phase and a solvent-rich phase.

**Industrial dry-spinning process steps:** **(a)** dissolution of polymer in solvent, **(b)** mixing and ripening of the polymer solution, **(c)** metering of the solution through the extruder, **(d)** filtration to remove mechanical impurities and undissolved polymer particles, **(e)** extrusion through the spinnerette into a heated inert-gas (mostly air) chamber — spinnerette hole diameter typically about **0.1–0.4 mm**, **(f)** solidification by the heated gas stream, **(g)** application of a spin finish (for lubrication and anti-static effect), and **(h)** collection of filament on a take-up bobbin.

**Advantages of dry spinning:** **(a)** recommended for heat-sensitive polymers; **(b)** high spinning speeds achievable; **(c)** relatively less solvent required overall, since a higher polymer concentration is used in the dope; **(d)** flexible — spinning conditions can be readily modified; **(e)** especially suited to filament-yarn production; **(f)** process layout is comparatively simple, similar to melt spinning.

**Disadvantages:** **(a)** solvent recovery adds cost/complexity and there is a practical limit on solvent choice; **(b)** because evaporation rate exceeds diffusion rate, achieving a truly circular fibre cross-section is difficult; **(c)** additional post-spinning treatment is needed to remove residual solvent completely; **(d)** careful control of spinnerette hole configuration/spacing is critical for uniform outward mass transfer.

**Table 2.5 — Polymers, solvents and solvent boiling points in dry spinning (reconstructed):**

| Polymer | Solvent | Boiling point of solvent |
|---|---|---|
| Cellulose acetate | Acetone | ≈56°C |
| Cellulose triacetate | Methylene chloride | ≈40°C |
| — | (or) Acetone | ≈56°C |
| Poly(acrylonitrile) (PAN) | Dimethylformamide (DMF) | ≈153°C |
| Poly(vinyl alcohol) (PVA) | Water | 100°C |

#### 3. Wet Spinning
**Principle:** applied to polymers that **do not melt (without decomposing) and dissolve only in non-volatile or thermally unstable solvents**. The polymer solution is metered by a **gear pump**, filtered, and extruded through a spinnerette that is **submerged directly in a coagulating ("spin") bath**, where the filament solidifies chemically/physically; the solidified filament is drawn out of the bath via godet/guide rollers. Take-up speed for wet spinning is comparatively low — of the order of **25–50 m/min**.

Dope preparation (dissolution, mixing, filtration, extrusion) closely parallels that of dry spinning, but a **more dilute polymer solution** is used (typically **5–25% polymer**, with dope viscosity in the range of roughly **20–5000 poise**) because the coagulation process is more complex. Spinnerette hole spacing in wet spinning is **closer together** than in dry spinning, since the extruded filament stream travels through a liquid medium (rather than air) after extrusion, and the surrounding liquid restricts filaments from coalescing during solidification.

**Spin block design:** unlike melt or dry spinning, the wet-spinning spin block is not a single compact unit; instead, spinnerettes are **submerged in the spin bath** and connected to the metering block by transfer pipes, and the spinnerette pack itself must be made of a **chemically inert material** (resistant to the coagulating chemicals).

**Solidification mechanism (Fig. 2.5):** solidification occurs by **extraction of the solvent from the dope by chemicals present in the spin bath** — an outward mass-transfer process, together with (in many cases) **inward mass transfer** of coagulating chemicals into the filament (an exchange/diffusion process). Solidification is governed by the relative rates of outward solvent transfer (S′) and inward coagulant transfer (S″): solidification proceeds properly when **S′ > S″ (i.e., S′/S″ > 1)**; a higher S′/S″ ratio is generally associated with denser, more uniform filament formation.

**Take-up:** because the filament emerges from a liquid bath, winding directly onto a bobbin is less convenient; **centrifugal ("pot") spinning** is commonly used instead — the filament is passed into a rapidly rotating pot/can, where it collects as a twisted "cake," which can then be handled as a package for downstream processing.

**Advantages of wet spinning:** it allows conversion of polymers into fibre with mechanical strength comparable to melt-spun fibres, and is particularly useful for **flexible-chain polymers that cannot be melt spun** (i.e., which decompose on melting).

**Disadvantages:** significant additional processing is required for **complete removal of residual solvent** from the filament, adding cost; the coagulation/solidification process is comparatively difficult to control precisely, which affects achievable spinning speed and resultant fibre uniformity/elongation properties, compared with melt spinning.

---

## Topic ix) Post-Spinning Operations — Drawing, Crimping, Heat-Setting and Texturisation

### (A) DRAWING

* **Chapter:** 2 – Fibre Formation
* **Page Number(s):** Book pp. 30–32 (PDF pages 45–46)
* **Extracted Content:**

Drawing (stretching) is applied to the as-spun (largely unoriented/amorphous) filament to develop **molecular orientation** and hence useful tenacity. The book lists the process **variables affecting drawing**: **(a) Draw ratio, (b) Feed velocity, (c) Temperature of drawing,** and **(d) Number of drawing stages** (single-stage vs. two-stage drawing, as also referenced in the Nylon and Polyester chapters).

**Effects of drawing on fibre structure/properties:**
- **(a)** Because of the imposed deformation, the **length of the fibre increases** and **orientation increases**.
- **(b)** Due to the higher molecular orientation, the drawn fibre shows **higher tenacity** (and generally reduced elongation-at-break).
- **(c)** **Crystallinity may change in either direction** — i.e., it may increase (as chains align and pack more regularly) or, in some cases, decrease, depending on the polymer and drawing conditions.
- **(d)** In some polymers, the **original (as-spun) structure is destroyed with formation of a new** (drawn/oriented) structure — this is generally observed for fibres such as **[nylon], polyethylene, polypropylene**, and related melt-spun thermoplastics, where drawing induces a distinct strain-induced crystallisation/orientation transition rather than a gradual modification of the existing structure.

*(The book's discussion of drawing is also cross-referenced within the individual fibre chapters — e.g., Nylon 6/66 drawing/high-oriented-yarn processes at book pp. ~209–211/221, and the Polyester "Drawing of the filament" step within the melt-spinning sequence at book p. ~248 — see Topic (vii) above for those fibre-specific drawing details.)*

---

### (B) CRIMPING, HEAT-SETTING AND TEXTURISATION

* **Chapter:** 19 – Processing of Fibres (Texturisation section)
* **Page Number(s):** Book pp. ~333–345 (PDF pages 345–357)
* **Extracted Content:**

**Definition:** *"Texturisation is defined as the means by which [permanent] bulk[iness], stretch[iness] ... [is imparted through] permanent introduction [of crimp/curl] ..."* into an otherwise smooth, straight synthetic filament yarn. *"Man-made fibres [as spun typically lack] aesthetic properties [comparable to natural fibres]. Owing to this, the fibres [or yarns] ... [are texturised]."* Textured yarns differ from the initial (flat, un-textured) yarn by having **higher bulk/porosity, softness, and often higher stretch/elasticity**.

**Broad classification of textured yarns:**
1. **Stretch yarns** — yarns with high potential stretch (the text cites stretch as high as **400%** for certain stretch-yarn types), produced by discontinuous or continuous twist-insertion/heat-setting/untwisting processes.
2. **Modified stretch yarns** — combine bulk with more moderate, controlled stretch.
3. **Bulk yarns** — emphasise bulkiness/coverage with relatively little stretch.

**Texturisation by mechanical methods — main processes:**

**(a) False-twist (stretch yarn) method (Fig. 19.4):** yarn is unwound from a supply package, fed through a heater, then through a **false-twist spindle/mechanism**, which inserts twist that runs back up through the heater zone (heat-setting the twisted configuration) and then is removed again downstream, leaving the yarn with a **latent helical crimp**. Process detail: yarn ends are twisted (one in "S," another in "Z" direction) using ring or double-twist spindles; yarns with both S and Z twist are then **steamed in an autoclave** (using hot air, hot water, or saturated steam) to heat-set the twist; internal residual torque (which would otherwise cause the yarn to untwist) is relieved by this heat-setting step. After steam-setting, the yarn is untwisted in a twister (by twisting in the opposite direction), and doubling of the two oppositely-twisted yarns can also be used to balance residual torque, producing a stable, balanced stretch yarn.

**(b) Modified false-twist method / Combined draw-texturing (Fig. 19.5):** stretch yarns can also be produced with the drawing (stretching) step combined into the texturing machine, immediately after the false-twist spindle — a one-step **"draw-texturing"** process.

**(c) Stuffer-box crimping (Fig. 19.6):** yarn is fed continuously into a heated chamber ("stuffer box"), where it is mechanically compressed/buckled into a random, folded (zig-zag) crimp configuration and heat-set in that compressed state; alternatively, single or plied yarn can be similarly crimped and heat-set.

**(d) Edge-crimping method (Fig. 19.7):** yarn is fed over a heated **edge-crimping unit** consisting of grooved rollers; the yarn passes over the sharp heated edge under tension so that one side is compressed while the opposite side is stretched, producing a **differential, unidirectional crimp**, and the crimped yarn is collected on a bobbin.

**(e) Gear-crimping method (Fig. 19.8):** yarn from the supply package is fed through a tension guide to a pair of **heated, intermeshing gears**; as the yarn passes between the gear teeth it is deflected into a sawtooth (zig-zag) path and heat-set in that configuration by the heated, enamelled gear surfaces, then collected via a guide roller.

**(f) Knit-de-knit method (Fig. 19.9):** described as a **"no-torque" texturisation process** — the yarn is knitted into a tubular fabric, heat-set in the knitted (looped) configuration (heat can be applied dry or with steam), and then **de-knitted** (unravelled) to recover the yarn, which now retains a permanent, non-torque crimp derived from the loop shape it held during heat-setting.

**(g) Air-jet (bulk) texturing:** yarn from a supply package is fed (with controlled overfeed) through an **air-jet device** using compressed air; the overfeeding causes excess yarn length to form random entangled loops within a turbulent air stream, which can be locked in place by light stabilisation/setting, giving a bulky, low-stretch textured yarn with a characteristic looped surface structure — distinct from the "true crimp" methods above.

**(h) Profile-extrusion / spinnerette-shape texturing:** texturisation-like bulk and complementary aesthetic effects can also be built in **at the spinning stage itself**, by using spinnerettes of non-round hole geometry ("profile-extruded" fibres), giving fibres of trilobal or other non-circular cross-sections that impart luster, bulk, or other textured-fabric-like handle without a separate mechanical texturing step; benefits cited include light weight, high coverage, and good draping qualities.

**Non-thermoplastic (regenerated cellulosic) texturisation:** the text notes that crimped viscose rayon ("crimp viscose") can also be produced by appropriate selection of spinning conditions (as an inherent-crimp fibre), or by post-treatment with solvents that swell the fibre, allowing the configuration to be altered and then locked in by controlled solvent removal, or by other similar physical/chemical routes — i.e., texturisation methods are not exclusive to thermoplastic synthetic fibres.

**Relationship to Heat-Setting:** across all the mechanical crimping/texturing methods above, a common and essential step is **heat-setting** — fixing the newly imposed (twisted, folded, gear-crimped, or knitted-loop) filament configuration permanently by exposing the yarn, while held in that configuration, to heat (dry heat, hot air, hot water, or saturated steam) at a temperature sufficient to relax internal stresses and "lock in" the new shape via re-crystallisation/relaxation of the polymer's amorphous regions; without this heat-setting step, the imposed crimp/twist would simply relax back out once tension is released (as described explicitly in the false-twist method's steaming/autoclave step above).

---

### (C) STAPLE FIBRE FORMATION (related post-spinning operation)

* **Chapter:** 19 – Processing of Fibres
* **Page Number(s):** Book pp. ~342–346 (PDF pages 354–358)
* **Extracted Content:**

Man-made fibres are typically produced first as **continuous filament (tow)**. For blending with natural fibres or for staple-spinning systems, filament tow must be cut/broken into **staple fibre** of a defined length. Cited advantages of staple fibre over continuous filament for blending purposes: **(a)** required (controlled) staple length, **(b)** determined fineness, **(c)** cleanliness, **(d)** absence of quality fluctuation, and **(e)** easy availability. Four systems of tow-to-staple conversion are named:

1. **Cutting method** (most common) — a uniformly spread tow is cut by a **revolving spiral cutter working against a hard steel roller** (Fig. 19.12); the cutter is set at an angular ("helix") arrangement (helix angle typically about 25°), and cutting edges are lined with synthetic rubber to prevent damage to the filaments during cutting; this method gives good control of fibre length.
2. **Abrasion method** — the filament tow is ruptured against an abrasive surface; disadvantages: cannot be applied to fibres with high abrasion resistance; there is little control over resulting fibre length (which can vary greatly, e.g., 1 cm to 25 cm); and the presence of many short fibres reduces mechanical/processing performance; generally used only for regenerated fibres or for niche/speciality applications.
3. **Stretch-breaking method** — based on the principle that if a filament tow is stretched under controlled conditions beyond its extensibility, it will break at random (naturally weak) points along its length; two sets of rollers running at different speeds (the delivery roller faster than the feed roller) impose the stretch; the fibre first stretches, then breaks at its weakest point; heating (contact heating) may be used to assist controlled stretch-breaking; typical draw ratios cited are on the order of up to about 2.0×, at temperatures of roughly **120–180°C**. This method gives reasonably uniform fibre-length distribution and can also increase fibre-bundle tenacity (though it lowers extensibility) compared with unbroken tow of the same fibre type.

*(A fourth conceptual category, "sawing"/other mechanical severing, is implied by the chapter's introductory list of methods but the corresponding detailed sub-section was not clearly legible in this scan.)*

After tow-to-staple conversion, the resulting staple fibre undergoes further finishing operations that mirror the fibre-specific post-treatment sequences described elsewhere in the book — for example, the text references a representative sequence for **viscose staple fibre**: *cutting → drying and intermediate opening → drying → [crimping] → further finishing.* Downstream processing of the manufactured staple fibre (opening, blending, carding, spinning) then proceeds broadly as for natural staple fibres.

---

---

## Summary — Topic Coverage Checklist

| # | Topic | Status |
|---|---|---|
| i | Definition of Textile Fibre; ideal-fibre properties | ✅ Found — Ch. 1 |
| ii | Classification of fibres (vegetable, animal, mineral, regenerated, synthetic) | ✅ Found — Ch. 1 |
| iii | Microscopic/physical/chemical identification test methods | ✅ Found — Ch. 20 |
| iv | Cotton, Jute, Linen — properties & uses | ✅ Found — Ch. 5 & Ch. 6 |
| v | Wool, Silk — properties & uses | ✅ Found — Ch. 8 & Ch. 9 |
| vi | Viscose Rayon; uses of HT Rayon | ✅ Found — Ch. 10 |
| vii | Polyester, Nylon 6,6, Acrylic | ✅ Found — Ch. 12, 13, 15 |
| viii | Requirements of fibre-forming polymers; Melt/Wet/Dry spinning | ✅ Found — Ch. 2 |
| ix | Post-spinning: Drawing, Crimping, Heat-setting, Texturisation | ✅ Found — Ch. 2 & Ch. 19 |

**No topics from the requested list were absent from the book** — all nine were located, several spanning more than one chapter (as noted individually above).

### A note on source fidelity
This PDF is a **photographed reproduction** of the printed book (visible page-curl, shadow and skew on many pages) rather than a flatbed scan, and several pages are faint or slightly out of focus. Optical character recognition (OCR) was used to locate and transcribe every relevant passage across all 377 pages. In the small number of places where individual words or short phrases were not legible even after enhancement, this is flagged in the text with square brackets, using surrounding technical context (chemistry/process logic) to bridge the gap — no numerical data, chemical facts, or named entities have been invented. Micrographs, line diagrams and photographic figures referenced throughout (e.g. cotton morphology Fig. 5.1–5.3, jute-stem anatomy Fig. 6.1, silk reeling Fig. 8.2, wool keratin Fig. 9.3–9.5, viscose-spinning Figs. 10.1–10.5, spinning-process Figs. 2.1–2.5, texturisation Figs. 19.4–19.9) are described narratively in context but could not be reproduced as images in this document — please refer to the cited PDF page numbers in your original file for the original figures/plates.
